import json
from typing import Optional, Any, Dict

from errors.exceptions import RagFlowAPIException
from utils.logger import logger
from fastapi import Request, status, FastAPI
from fastapi.exceptions import HTTPException as FastAPIHTTPException
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException


def create_openai_error_response_content(
    message: str,
    type_: str = "invalid_request_error",
    param: Optional[str] = None,
    code: Optional[str] = None,
    internal_message: Optional[str] = None, 
    status_code: Optional[int] = None 
) -> Dict[str, Any]:
    """
    Creates the content dictionary for an OpenAI-style error response.
    """
    error_payload: Dict[str, Optional[str]] = {
        "message": message,
        "type": type_,
        "param": param,
        "code": code,
    }
    return { "error": {k: v for k, v in error_payload.items() if v is not None} }

async def handle_ragflow_api_exception(request: Request, exc: RagFlowAPIException) -> JSONResponse:
    logger.error(
        f"RagFlowAPIException caught: {exc.message} (Status: {exc.status_code}, Code: {exc.code}, Details: {exc.details})",
        exc_info=True 
    )
    error_content = create_openai_error_response_content(
        message=exc.message,
        type_="api_error", 
        code=exc.code,
        internal_message=f"RagFlow API Error: {exc.details}" if exc.details else None,
        status_code=exc.status_code
    )
    return JSONResponse(
        status_code=exc.status_code if exc.status_code and exc.status_code >= 400 else 500, 
        content=error_content,
        media_type="application/json; charset=utf-8"
    )

async def handle_fastapi_http_exception(request: Request, exc: FastAPIHTTPException) -> JSONResponse:
    logger.warning(
        f"HTTPException caught: {exc.detail} (Status: {exc.status_code})",
    )
    error_type = "invalid_request_error"
    if exc.status_code == 401:
        error_type = "authentication_error"
    elif exc.status_code == 403:
        error_type = "permission_error"
    elif exc.status_code == 404:
        error_type = "not_found_error"
    elif exc.status_code == 429:
        error_type = "rate_limit_error"
    elif exc.status_code >= 500:
        error_type = "api_error" 

    # If exc.detail is already a dict (our OpenAI-formatted error), use it directly
    if isinstance(exc.detail, dict) and 'error' in exc.detail:
        error_content = exc.detail
    elif isinstance(exc.detail, str): # If it's a simple string detail
        error_content = create_openai_error_response_content(
            message=exc.detail, 
            type_=error_type,
            status_code=exc.status_code
        )
    else: # Fallback for other types of detail
        error_content = create_openai_error_response_content(
            message=str(exc.detail),
            type_=error_type,
            status_code=exc.status_code
        )

    headers = getattr(exc, "headers", None)
    return JSONResponse(
        status_code=exc.status_code,
        content=error_content,
        headers=headers,
        media_type="application/json; charset=utf-8"
    )

async def handle_starlette_http_exception(request: Request, exc: StarletteHTTPException) -> JSONResponse:
    logger.warning(
        f"Starlette HTTPException caught: {exc.detail} (Status: {exc.status_code})"
    )
    error_type = "invalid_request_error"
    if exc.status_code == 401:
        error_type = "authentication_error"
    elif exc.status_code >= 500:
        error_type = "api_error"

    if isinstance(exc.detail, dict) and 'error' in exc.detail:
        error_content = exc.detail
    elif isinstance(exc.detail, str):
        error_content = create_openai_error_response_content(
            message=exc.detail,
            type_=error_type,
            status_code=exc.status_code
        )
    else:
        error_content = create_openai_error_response_content(
            message=str(exc.detail),
            type_=error_type,
            status_code=exc.status_code
        )
        
    headers = getattr(exc, "headers", None)
    return JSONResponse(
        status_code=exc.status_code,
        content=error_content,
        headers=headers,
        media_type="application/json; charset=utf-8"
    )


async def handle_generic_exception(request: Request, exc: Exception) -> JSONResponse:
    logger.error(f"Unhandled generic exception caught: {str(exc)}", exc_info=True)
    error_content = create_openai_error_response_content(
        message="An unexpected internal server error occurred.",
        type_="internal_server_error", 
        code="internal_error",
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
    )
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=error_content,
        media_type="application/json; charset=utf-8"
    )

def register_exception_handlers(app: FastAPI) -> None:
    """Registers all custom exception handlers for the FastAPI application."""
    app.add_exception_handler(RagFlowAPIException, handle_ragflow_api_exception)
    app.add_exception_handler(FastAPIHTTPException, handle_fastapi_http_exception)
    app.add_exception_handler(StarletteHTTPException, handle_starlette_http_exception)
    app.add_exception_handler(Exception, handle_generic_exception)
    logger.info("Custom exception handlers registered.")

if __name__ == '__main__':
    print("OpenAI-style error response content examples:")
    error_example = create_openai_error_response_content(
        message="User message not found in 'messages'",
        type_="invalid_request_error",
        param="messages",
        code="missing_user_message"
    )
    print(json.dumps(error_example, indent=2))

    error_example_minimal = create_openai_error_response_content(
        message="Resource not found."
    )
    print(json.dumps(error_example_minimal, indent=2)) 