"""
Ollama服务模块
实现与Ollama API的交互，提供文本生成和总结功能
"""

import asyncio
import time
from typing import Optional, Dict, Any, List

import ollama
from device_kb_service.utils.logger import logger

from device_kb_service.config import settings
from device_kb_service.core.models import OllamaGenerateResponse, TextSummaryResponse
from device_kb_service.errors import ServiceError, ServiceConnectionError


class OllamaServiceError(ServiceError):
    """Ollama服务异常"""
    pass


class OllamaService:
    """
    Ollama服务客户端
    使用ollama Python SDK提供与Ollama API交互的功能
    """

    def __init__(self):
        self.base_url = settings.ollama_base_url
        self.model = settings.ollama_model
        self.timeout = settings.ollama_timeout
        self.max_retries = settings.ollama_max_retries
        self.retry_delay = settings.ollama_retry_delay

        # 去除末尾的斜杠
        if self.base_url.endswith('/'):
            self.base_url = self.base_url.rstrip('/')

        # 初始化ollama客户端
        self.client = ollama.Client(host=self.base_url)

        logger.info(f"初始化Ollama服务: {self.base_url}, 模型: {self.model}")

    async def _generate_with_retry(self, prompt: str, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        生成文本，仅对连接错误进行重试
        
        Args:
            prompt: 输入提示词
            options: 可选的生成参数
            
        Returns:
            生成响应数据
            
        Raises:
            OllamaServiceError: 请求失败时抛出
        """
        logger.debug(f"发送请求到Ollama - 模型: {self.model}, 提示词长度: {len(prompt)}")
        
        try:
            # 使用ollama SDK生成文本
            response = self.client.generate(
                model=self.model,
                prompt=prompt,
                stream=False,
                options=options or {}
            )
            
            # 将 ollama 响应对象转换为字典
            if hasattr(response, '__dict__'):
                response_dict = response.__dict__
            elif hasattr(response, 'model_dump'):
                response_dict = response.model_dump()
            elif isinstance(response, dict):
                response_dict = response
            else:
                # 手动构建响应字典
                response_dict = {
                    'model': getattr(response, 'model', self.model),
                    'created_at': getattr(response, 'created_at', ''),
                    'response': getattr(response, 'response', ''),
                    'done': getattr(response, 'done', True),
                    'total_duration': getattr(response, 'total_duration', None),
                    'load_duration': getattr(response, 'load_duration', None),
                    'prompt_eval_count': getattr(response, 'prompt_eval_count', None),
                    'prompt_eval_duration': getattr(response, 'prompt_eval_duration', None),
                    'eval_count': getattr(response, 'eval_count', None),
                    'eval_duration': getattr(response, 'eval_duration', None),
                }
            
            logger.debug(f"Ollama生成成功: {response_dict.get('response', '')[:100]}...")
            return response_dict
            
        except ollama.RequestError as e:
            # 网络连接错误 - 进行有限重试
            logger.warning(f"Ollama连接错误，进行重试: {str(e)}")
            
            for attempt in range(self.max_retries):
                try:
                    logger.debug(f"重试连接Ollama (尝试 {attempt + 1}/{self.max_retries})")
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
                    
                    response = self.client.generate(
                        model=self.model,
                        prompt=prompt,
                        stream=False,
                        options=options or {}
                    )
                    
                    # 转换响应格式（重复上面的逻辑）
                    if hasattr(response, '__dict__'):
                        response_dict = response.__dict__
                    elif hasattr(response, 'model_dump'):
                        response_dict = response.model_dump()
                    elif isinstance(response, dict):
                        response_dict = response
                    else:
                        response_dict = {
                            'model': getattr(response, 'model', self.model),
                            'created_at': getattr(response, 'created_at', ''),
                            'response': getattr(response, 'response', ''),
                            'done': getattr(response, 'done', True),
                            'total_duration': getattr(response, 'total_duration', None),
                            'load_duration': getattr(response, 'load_duration', None),
                            'prompt_eval_count': getattr(response, 'prompt_eval_count', None),
                            'prompt_eval_duration': getattr(response, 'prompt_eval_duration', None),
                            'eval_count': getattr(response, 'eval_count', None),
                            'eval_duration': getattr(response, 'eval_duration', None),
                        }
                    
                    logger.info(f"Ollama重连成功: {response_dict.get('response', '')[:100]}...")
                    return response_dict
                    
                except ollama.RequestError as retry_e:
                    if attempt == self.max_retries - 1:
                        logger.error(f"Ollama连接重试失败，已达最大重试次数: {str(retry_e)}")
                        raise ServiceConnectionError(f"无法连接到Ollama服务: {self.base_url}")
                    continue
                except Exception as retry_e:
                    logger.error(f"重试过程中发生其他错误: {str(retry_e)}")
                    raise OllamaServiceError(f"Ollama请求异常: {str(retry_e)}")
                    
        except ollama.ResponseError as e:
            # API响应错误 - 快速失败
            logger.error(f"Ollama API响应错误，快速失败: {str(e)}")
            raise OllamaServiceError(f"Ollama API响应错误: {str(e)}")
            
        except Exception as e:
            # 其他异常 - 快速失败
            logger.error(f"Ollama请求异常，快速失败: {str(e)}")
            raise OllamaServiceError(f"Ollama请求异常: {str(e)}")

    async def generate_text(self, prompt: str, options: Optional[Dict[str, Any]] = None) -> OllamaGenerateResponse:
        """
        生成文本
        
        Args:
            prompt: 输入提示词
            options: 可选的生成参数
            
        Returns:
            生成的文本响应
        """
        response_data = await self._generate_with_retry(prompt, options)
        return OllamaGenerateResponse(**response_data)

    async def summarize_text(self, text: str, max_length: int = 20) -> TextSummaryResponse:
        """
        总结文本主题
        
        Args:
            text: 待总结的文本
            max_length: 总结最大长度（字符数）
            
        Returns:
            文本主题总结结果
        """
        # 验证输入
        if not text or not text.strip():
            raise OllamaServiceError("输入文本不能为空")

        # 构建提示词
        prompt = f"""请为以下文本生成一个简洁的主题总结，要求：
1. 不超过{max_length}个字符
2. 准确概括文本核心内容
3. 语言简洁明了
4. 直接输出主题，不要额外解释
5. 不要包含思考过程或标签

文本内容：
{text.strip()}

主题总结："""

        start_time = time.time()

        try:
            # 调用Ollama生成总结
            response_data = await self._generate_with_retry(prompt)

            # 处理响应
            summary = response_data.get('response', '').strip()

            # 确保总结长度不超过限制
            if len(summary) > max_length:
                summary = summary[:max_length]

            duration = time.time() - start_time

            logger.info(f"文本主题总结完成，耗时: {duration:.2f}秒")
            logger.debug(f"原文本: {text[:100]}...")
            logger.debug(f"生成总结: {summary}")

            return TextSummaryResponse(
                summary=summary,
                original_text=text,
                model=self.model,
                duration=duration
            )

        except Exception as e:
            logger.error(f"文本总结失败: {str(e)}")
            raise OllamaServiceError(f"文本总结失败: {str(e)}")

    async def guess_next_questions(self, last_messages: List[Dict[str, str]]) -> List[str]:
        """
        猜你想问功能 - 基于对话历史预测用户可能想继续咨询的问题
        
        Args:
            last_messages: 最后几条消息，格式为 [{"role": "user|assistant", "content": "..."}]
            
        Returns:
            List[str]: 5个预测的问题
        """
        if not last_messages:
            return []
        
        # 构建对话历史文本
        conversation_text = ""
        for msg in last_messages[-5:]:  # 只取最后5条
            role = msg.get('role', '')
            content = msg.get('content', '')
            if role == 'user':
                conversation_text += f"用户: {content}\n"
            elif role == 'assistant':
                conversation_text += f"助手: {content}\n"
        
        # 构建提示词 - 优化以避免输出思考过程
        prompt = f"""你是一个设备故障诊断专家AI助手。基于以下对话历史，预测用户可能想继续咨询的5个问题。

对话历史：
{conversation_text.strip()}

请直接输出5个问题，格式如下：
问题1：[具体问题内容]
问题2：[具体问题内容]  
问题3：[具体问题内容]
问题4：[具体问题内容]
问题5：[具体问题内容]

要求：
- 每个问题都与设备故障诊断、维护、排查相关
- 问题应该基于当前对话内容，是用户可能想深入了解的
- 问题要具体、实用，避免太宽泛
- 每个问题不超过20个字
- 不要包含思考过程或解释

5个预测问题："""

        try:
            logger.debug(f"猜你想问 - 基于 {len(last_messages)} 条消息生成问题")
            
            response_data = await self._generate_with_retry(prompt, {"temperature": 0.7, "max_tokens": 300})
            response_text = response_data.get('response', '').strip()
            
            # 解析响应，提取问题列表
            questions = []
            lines = response_text.split('\n')
            
            # 第一遍：查找明确格式的问题
            for line in lines:
                line = line.strip()
                if not line or len(questions) >= 5:
                    continue
                
                # 过滤思考过程
                if any(keyword in line.lower() for keyword in ['<think>', '</think>', 'think>', '好的，用户', '首先，', '接下来，', '然后，', '另外，', '最后，', '这些都']):
                    continue
                
                # 查找问题格式
                clean_question = None
                
                # 格式1: "问题X：内容"
                if line.startswith('问题') and ('：' in line or ':' in line):
                    clean_question = line.split('：', 1)[1].strip() if '：' in line else line.split(':', 1)[1].strip()
                
                # 格式2: 以问号结尾的句子
                elif line.endswith('？') or line.endswith('?'):
                    # 移除可能的编号前缀
                    if line.startswith(('1.', '2.', '3.', '4.', '5.', '1、', '2、', '3、', '4、', '5、')):
                        clean_question = line[2:].strip()
                    elif line[0].isdigit() and len(line) > 1 and line[1] in ['.', '、', ' ', ')', '）']:
                        clean_question = line[2:].strip()
                    else:
                        clean_question = line
                
                # 格式3: 数字开头的短句
                elif line[0].isdigit() and len(line) > 1 and line[1] in ['.', '、', ' '] and len(line) < 50:
                    clean_question = line[2:].strip()
                
                if clean_question and len(clean_question) > 3 and len(clean_question) <= 30:
                    questions.append(clean_question)
            
            # 如果第一遍没找到足够问题，第二遍放宽条件
            if len(questions) < 3:
                for line in lines:
                    line = line.strip()
                    if not line or len(questions) >= 5:
                        continue
                    
                    # 跳过明显的思考过程
                    if len(line) > 100 or any(keyword in line for keyword in ['用户之前', '我需要', '可能想知道', '因为这是', '符合用户']):
                        continue
                    
                    # 查找包含关键词的短句
                    if any(keyword in line for keyword in ['如何', '是否', '需要', '多久', '什么', '怎么', '会不会']) and len(line) <= 30:
                        if line.startswith(('1.', '2.', '3.', '4.', '5.', '1、', '2、', '3、', '4、', '5、')):
                            line = line[2:].strip()
                        elif line[0].isdigit() and len(line) > 1 and line[1] in ['.', '、', ' ']:
                            line = line[2:].strip()
                        
                        if line not in questions:
                            questions.append(line)
            
            # 确保返回5个问题，不足则补充默认问题
            default_questions = [
                "如何清洁这个部件？",
                "这种故障通常多久出现一次？",
                "有什么预防措施可以避免？", 
                "需要请专业师傅检查吗？",
                "大概多长时间能修好？"
            ]
            
            while len(questions) < 5:
                questions.append(default_questions[len(questions)])
            
            logger.info(f"猜你想问生成完成，返回 {len(questions[:5])} 个问题")
            return questions[:5]
            
        except Exception as e:
            logger.error(f"猜你想问功能失败: {str(e)}")
            # 返回默认问题
            return [
                "如何清洁这个部件？",
                "这种故障通常多久出现一次？",
                "有什么预防措施可以避免？", 
                "需要请专业师傅检查吗？",
                "大概多长时间能修好？"
            ]


# 全局Ollama服务实例
ollama_service = OllamaService()


# 便捷函数
async def get_text_summary(text: str, max_length: int = 20) -> str:
    """
    获取文本主题总结的便捷函数
    
    Args:
        text: 待总结的文本
        max_length: 总结最大长度
        
    Returns:
        主题总结字符串
    """
    result = await ollama_service.summarize_text(text, max_length)
    return result.summary
