import time
from typing import List

from utils.logger import logger
from fastapi import APIRouter, Request
from pydantic import BaseModel, Field


# --- OpenAI Model Response Models ---
class OpenAIModelObject(BaseModel):
    id: str
    object: str = Field(default="model")
    created: int
    owned_by: str

class OpenAIModelsResponse(BaseModel):
    object: str = Field(default="list")
    data: List[OpenAIModelObject]

router = APIRouter()

# Define available models
AVAILABLE_MODELS = [
    {
        "id": "device_fault_master",
        "description": "Device Fault Diagnosis Master Model",
        "owned_by": "device_kb_service"
    }
]

@router.get("/models",
            response_model=OpenAIModelsResponse,
            summary="Lists the currently available models.",
            tags=["Models"])
async def list_models_endpoint(request: Request) -> OpenAIModelsResponse:
    """
    Lists the currently available models, and provides basic information about each one
    such as the owner and availability.
    """
    logger.info(f"Models list requested from {request.client.host if request.client else 'unknown'}")
    
    # Convert internal model list to OpenAI format
    model_objects = []
    created_time = int(time.time())
    
    for model in AVAILABLE_MODELS:
        model_obj = OpenAIModelObject(
            id=model["id"],
            created=created_time,
            owned_by=model["owned_by"]
        )
        model_objects.append(model_obj)
    
    response = OpenAIModelsResponse(data=model_objects)
    
    logger.debug(f"Returning {len(model_objects)} models")
    return response

@router.get("/models/{model_id}",
            response_model=OpenAIModelObject,
            summary="Retrieves a model instance.",
            tags=["Models"])
async def retrieve_model_endpoint(model_id: str, request: Request) -> OpenAIModelObject:
    """
    Retrieves a model instance, providing basic information about the model
    such as the owner and permissioning.
    """
    logger.info(f"Model {model_id} requested from {request.client.host if request.client else 'unknown'}")
    
    # Find the requested model
    for model in AVAILABLE_MODELS:
        if model["id"] == model_id:
            return OpenAIModelObject(
                id=model["id"],
                created=int(time.time()),
                owned_by=model["owned_by"]
            )
    
    # If model not found, return 404
    from fastapi import HTTPException
    raise HTTPException(
        status_code=404,
        detail={"error": {"message": f"Model '{model_id}' not found.", "type": "not_found_error", "code": "model_not_found"}}
    ) 