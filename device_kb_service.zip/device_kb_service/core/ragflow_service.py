import time
from typing import Generator, Optional, Dict, Any
from ragflow_sdk import RAGFlow

from device_kb_service.config import settings
from device_kb_service.utils.logger import logger
from device_kb_service.errors.exceptions import SessionError


class RagFlowService:
    """
    RagFlow业务服务类，封装所有与RagFlow交互的逻辑。
    
    职责：
    - 聊天会话创建和管理
    - 消息发送和响应处理
    - 业务级错误处理
    """
    
    def __init__(self, ragflow_client: RAGFlow):
        """
        初始化RagFlow服务。
        
        Args:
            ragflow_client: RAGFlow SDK客户端实例
        """
        self.ragflow = ragflow_client
        self._active_sessions: Dict[str, Any] = {}
    
    def create_chat_session(self, assistant_name: str = None):
        """
        创建新的聊天会话。
        
        Args:
            assistant_name: 助手名称，默认使用配置中的名称
            
        Returns:
            创建的会话对象
            
        Raises:
            SessionError: 会话创建失败时抛出
        """
        try:
            # 使用提供的助手名称或默认配置
            assistant_name = assistant_name or settings.ragflow_assistant_name
            
            logger.info(f"查找聊天助手: {assistant_name}")
            logger.debug(f"调用 list_chats(name={assistant_name})")
            
            assistants = self.ragflow.list_chats(name=assistant_name)
            logger.info(f"list_chats 返回结果数量: {len(assistants) if assistants else 0}")
            
            if not assistants:
                error_msg = f"未找到名为 {assistant_name} 的聊天助手"
                logger.error(error_msg)
                # 尝试获取所有助手进行调试
                all_assistants = self.ragflow.list_chats()
                logger.info(f"当前可用的助手总数: {len(all_assistants) if all_assistants else 0}")
                if all_assistants:
                    assistant_names = [getattr(a, 'name', 'Unknown') for a in all_assistants[:5]]
                    logger.info(f"可用助手名称示例: {assistant_names}")
                raise SessionError(error_msg)
            
            assistant = assistants[0]
            logger.info(f"找到聊天助手: {assistant_name}, ID: {assistant.id}")
            
            # 创建会话
            logger.debug(f"调用 assistant.create_session() for assistant {assistant.id}")
            session = assistant.create_session()
            logger.info(f"创建会话成功，会话ID: {session.id}")
            
            # 添加短暂延迟以确保会话完全初始化
            time.sleep(0.5)
            logger.debug(f"会话初始化延迟完成")
            
            return session
            
        except Exception as e:
            if isinstance(e, SessionError):
                raise
            error_msg = f"创建聊天会话失败: {type(e).__name__}('{str(e)}')"
            logger.error(error_msg)
            logger.error(f"错误详情 - assistant_name: {assistant_name}")
            raise SessionError(error_msg)
    
    def send_message_stream(self, session, message: str) -> Generator[tuple[str, list], None, None]:
        """
        向会话发送消息并获取流式增量回复。
        
        专门用于流式响应，直接返回增量内容和引用信息，避免API层重复计算。
        
        Args:
            session: 会话对象
            message: 要发送的消息
            
        Yields:
            tuple[str, list]: (响应内容增量片段, 引用信息列表)
            
        Raises:
            Exception: 消息发送失败时抛出
        """
        try:
            logger.info(f"向会话 {session.id} 发送流式消息: {message[:100]}{'...' if len(message) > 100 else ''}")
            
            response_count = 0
            total_content_length = 0
            last_content = ""
            start_time = time.time()
            first_response_time = None
            final_references = []  # 存储最终的引用信息
            
            try:
                for response in session.ask(message, stream=True):
                    response_count += 1
                    current_time = time.time()
                    
                    # 记录首次响应时间
                    if first_response_time is None:
                        first_response_time = current_time
                        logger.info(f"首次响应延迟: {(first_response_time - start_time):.2f}秒")
                    
                    # 获取当前累积内容
                    content = response.content or ""
                    current_length = len(content)
                    
                    # 记录引用信息（如果有）
                    if hasattr(response, 'reference') and response.reference:
                        logger.debug(f"响应块#{response_count}包含{len(response.reference)}条引用")
                        # 更新最终引用信息（通常在最后一个响应块中包含完整引用）
                        final_references = response.reference
                    
                    # 计算并返回增量内容
                    if current_length > len(last_content):
                        delta_content = content[len(last_content):]
                        delta_length = len(delta_content)
                        total_content_length += delta_length
                        
                        # 记录增量信息
                        if delta_length > 0:
                            delta_preview = delta_content[:50].replace('\n', '\\n')
                            if len(delta_content) > 50:
                                delta_preview += "..."
                            logger.debug(f"响应块#{response_count}: +{delta_length}字符 '{delta_preview}'")
                            
                            # 返回增量内容和当前的引用信息
                            yield (delta_content, [])  # 流式过程中暂不返回引用
                        else:
                            logger.debug(f"响应块#{response_count}: 无新内容")
                        
                        last_content = content
                    else:
                        logger.warning(f"响应块#{response_count}: 内容长度未增加 (当前:{current_length}, 之前:{len(last_content)})")
                
                # 在流结束时，如果有引用信息，发送一个特殊的标记
                if final_references:
                    logger.info(f"流式响应完成，包含{len(final_references)}条引用")
                    # 直接返回ragflow的原始引用数据，让前端处理格式适配
                    logger.debug(f"返回原始引用数据: {final_references[:1]}...")  # 只记录第一条作为示例
                    yield ("", final_references)  # 空内容，但包含原始引用信息
                
                # 统计信息
                total_time = time.time() - start_time
                avg_response_time = (total_time / response_count) if response_count > 0 else 0
                chars_per_second = (total_content_length / total_time) if total_time > 0 else 0
                
                logger.info(f"流式响应完成 - 响应块数:{response_count}, 总字符数:{total_content_length}, "
                          f"总耗时:{total_time:.2f}s, 平均响应间隔:{avg_response_time:.3f}s, "
                          f"生成速度:{chars_per_second:.1f}字符/秒")
                
                # 警告：无响应情况
                if response_count == 0:
                    logger.warning("session.ask() 没有产生任何响应块")
                elif total_content_length == 0:
                    logger.warning("流式响应完成但未生成任何内容")
                    
            except Exception as ask_e:
                logger.error(f"session.ask() 调用失败: {type(ask_e).__name__}('{str(ask_e)}')")
                raise Exception(f"发送消息失败: {str(ask_e)}")
                
        except Exception as e:
            error_msg = f"发送流式消息失败: {type(e).__name__}('{str(e)}')"
            logger.error(error_msg)
            logger.error(f"错误详情 - session_id: {session.id}, message_length: {len(message)}")
            raise Exception(error_msg)
    
    def send_message(self, session, message: str) -> str:
        """
        向会话发送消息并获取完整回复。
        
        专门用于非流式响应，返回完整的响应内容。
        
        Args:
            session: 会话对象
            message: 要发送的消息
            
        Returns:
            str: 完整的响应内容
            
        Raises:
            Exception: 消息发送失败时抛出
        """
        try:
            logger.info(f"向会话 {session.id} 发送非流式消息: {message[:100]}{'...' if len(message) > 100 else ''}")
            
            start_time = time.time()
            response = session.ask(message, stream=False)
            response_time = time.time() - start_time
            
            content = response.content or ""
            logger.info(f"非流式响应完成 - 耗时:{response_time:.2f}s, 内容长度:{len(content)}字符")
            
            # 只在调试模式下显示内容预览
            if logger.level <= 10:  # DEBUG level
                content_preview = content[:200].replace('\n', '\\n')
                if len(content) > 200:
                    content_preview += "..."
                logger.debug(f"响应内容预览: '{content_preview}'")
            
            # 记录引用信息（如果有）
            if hasattr(response, 'reference') and response.reference:
                logger.info(f"响应包含{len(response.reference)}条引用")
            
            return content
            
        except Exception as e:
            error_msg = f"发送非流式消息失败: {type(e).__name__}('{str(e)}')"
            logger.error(error_msg)
            logger.error(f"错误详情 - session_id: {session.id}, message_length: {len(message)}")
            raise Exception(error_msg)
    
    def get_or_create_session(self, session_key: str):
        """
        获取现有会话或创建新会话。
        
        Args:
            session_key: 会话唯一标识
            
        Returns:
            会话对象
            
        Raises:
            SessionError: 会话创建失败时抛出
        """
        logger.debug(f"检查会话缓存，session_key: {session_key}")
        
        if session_key in self._active_sessions:
            session = self._active_sessions[session_key]
            logger.info(f"使用缓存会话: session_id={session.id}")
            return session
        
        try:
            logger.info(f"创建新会话，session_key: {session_key}")
            session = self.create_chat_session()
            self._active_sessions[session_key] = session
            logger.info(f"新会话创建成功: session_id={session.id}")
            return session
        except Exception as e:
            error_msg = f"Failed to create session: {type(e).__name__}('{str(e)}')"
            logger.error(error_msg)
            logger.error(f"会话创建失败详情 - session_key: {session_key}")
            raise SessionError(f"Failed to create chat session: {str(e)}")
    
    def invalidate_session(self, session_key: str) -> None:
        """
        使会话缓存失效。
        
        Args:
            session_key: 要失效的会话标识
        """
        if session_key in self._active_sessions:
            del self._active_sessions[session_key]
            logger.info(f"会话已从缓存中移除: {session_key}")
    
    def get_session_count(self) -> int:
        """获取当前活跃会话数量。"""
        return len(self._active_sessions) 
    