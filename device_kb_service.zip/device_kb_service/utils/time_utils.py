import time
from typing import Optional # Added Optional

def format_http_date(timestamp: Optional[float] = None) -> str:
    """
    Formats a given Unix timestamp into an HTTP-compliant date string (RFC 1123).
    If no timestamp is provided, the current time is used.
    """
    if timestamp is None:
        timestamp = time.time()
    
    time_struct = time.gmtime(timestamp)
    
    weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

    return '{}, {:02d} {} {:04d} {:02d}:{:02d}:{:02d} GMT'.format(
        weekdays[time_struct.tm_wday],
        time_struct.tm_mday,
        months[time_struct.tm_mon - 1],
        time_struct.tm_year,
        time_struct.tm_hour,
        time_struct.tm_min,
        time_struct.tm_sec
    )

if __name__ == '__main__':
    print("Current time (HTTP Date format):")
    print(format_http_date())

    specific_timestamp = 1678886400 # March 15, 2023 12:00:00 PM GMT
    print(f"\nSpecific timestamp ({specific_timestamp}) in HTTP Date format:")
    print(format_http_date(specific_timestamp)) 