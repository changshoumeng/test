# device_kb_service/.env
# ============================
# RagFlow知识库配置
# ============================
RAGFLOW_API_KEY=ragflow-hlODFhODI2M2Y0YTExZjA4NDk0NzI2ZG
RAGFLOW_BASE_URL=http://192.168.56.120
RAGFLOW_ASSISTANT_NAME=zhzg-设备故障诊断专家
RAGFLOW_MAX_RETRIES=3
RAGFLOW_RETRY_DELAY=0.5

# ============================
# LLM服务配置
# ============================
# 支持的提供商: ollama | siliconflow | openai | anthropic
LLM_PROVIDER=siliconflow

# Ollama配置 (当LLM_PROVIDER=ollama时使用)
OLLAMA_BASE_URL=http://10.28.132.113:11434
OLLAMA_MODEL=qwq-32b-fp16_32768:latest
OLLAMA_TIMEOUT=30
OLLAMA_MAX_RETRIES=3
OLLAMA_RETRY_DELAY=1.0

# SiliconFlow配置 (当LLM_PROVIDER=siliconflow时使用)
SILICONFLOW_API_KEY=sk-qpxraicbqgivyagsoluwnfxzfembyouvldevsdllulmxoeaj
SILICONFLOW_BASE_URL=https://api.siliconflow.cn/v1
SILICONFLOW_MODEL=deepseek-ai/DeepSeek-V3

# OpenAI配置 (当LLM_PROVIDER=openai时使用)
OPENAI_API_KEY=
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4

# Anthropic配置 (当LLM_PROVIDER=anthropic时使用)
ANTHROPIC_API_KEY=
ANTHROPIC_MODEL=claude-3-sonnet-20240229

# ============================
# OpenAI兼容API配置
# ============================
DEFAULT_MODEL=device_fault_master
API_PREFIX=/device_kb/v1
SERVICE_OPENAI_API_KEY=sk-A6Bt70N70zl6ifqhmwvxJL1UDTB1doXW5wCyhWltYovJkKlF
REQUIRE_AUTH=false

# ============================
# 应用服务配置
# ============================
APP_NAME=DeviceKBService
APP_VERSION=1.5.0
APP_HOST=0.0.0.0
APP_PORT=8089
APP_TIMEOUT=120
APP_RELOAD=false
APP_WORKERS=

# ============================
# 日志配置
# ============================
LOG_LEVEL=DEBUG
LOG_DIR=logs

# ============================
# LiteLLM通用配置
# ============================
# LiteLLM超时设置
LITELLM_TIMEOUT=30
LITELLM_MAX_RETRIES=3
LITELLM_RETRY_DELAY=1.0

# 温度和生成参数
DEFAULT_TEMPERATURE=0.7
DEFAULT_MAX_TOKENS=2000
DEFAULT_STREAM=true 