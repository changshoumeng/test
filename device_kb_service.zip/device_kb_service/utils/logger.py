import os
import sys # Added sys for loguru initialization
from loguru import logger

from device_kb_service.config import settings

def setup_logging():
    """
    Configures the application's logger using Loguru.
    Log level and directory are sourced from the application settings.
    Removes default Loguru handler and adds configured ones.
    """
    logger.remove() # Remove default handler to prevent duplicate console logs

    # Console Handler
    # Loguru's default format is quite good and includes time, level, name, message.
    # For more detailed tracebacks, Loguru handles them automatically.
    # Format similar to original: "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
    # Simplified format for clarity:
    log_format_console = (
        "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
        "<level>{level: <8}</level> | "
        "<cyan>{name}:{function}:{line}</cyan> - <level>{message}</level>"
    )
    logger.add(
        sys.stderr,  # Default sink for console
        level=settings.log_level.upper(),
        format=log_format_console,
        colorize=True
    )

    # File Handlers (if log_dir is configured)
    if settings.log_dir:
        try:
            log_dir_path = settings.log_dir
            os.makedirs(log_dir_path, exist_ok=True)

            # General file log (similar to console format, but without color)
            log_format_file = (
                "{time:YYYY-MM-DD HH:mm:ss.SSS} | "
                "{level: <8} | "
                "{name}:{function}:{line} - {message}"
            )
            logger.add(
                os.path.join(log_dir_path, "device_kb.log"),
                level=settings.log_level.upper(),
                format=log_format_file,
                rotation="10 MB",  # Rotate when file exceeds 10 MB
                retention="7 days", # Keep logs for 7 days
                compression="zip", # Compress rotated files
                encoding='utf-8'
            )

            # Error-specific file log
            # This will capture ERROR and CRITICAL messages specifically.
            logger.add(
                os.path.join(log_dir_path, "device_kb_error.log"),
                level="ERROR",
                format=log_format_file, # Can use a more detailed format if needed for errors
                rotation="10 MB",
                retention="7 days",
                compression="zip",
                encoding='utf-8'
            )
            logger.info(f"File logging enabled with Loguru. Log directory: {log_dir_path}")

        except Exception as e:
            # If file logging setup fails, Loguru will still log to console (stderr by default)
            logger.error(f"Error setting up file loggers in '{settings.log_dir}' with Loguru: {e}.", exc_info=True)
            logger.info("File logging disabled due to error. Console logging remains active.")
    else:
        logger.info("LOG_DIR not set. File logging will be skipped.")
    
    # The logger instance is already imported from loguru, no need to return it.
    # Configure global exception hook for uncaught exceptions
    def handle_exception(exc_type, exc_value, exc_traceback):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_traceback)
            return
        logger.opt(exception=(exc_type, exc_value, exc_traceback)).critical("Uncaught exception:")

    sys.excepthook = handle_exception
    logger.info("Loguru logging configured.")

# Call setup_logging() when this module is imported to configure the logger instance.
# This makes `from device_kb_service.utils.logger import logger` provide the configured logger.
setup_logging()

if __name__ == '__main__':
    # This block is for testing the logger setup directly.
    logger.info("Testing Loguru logger configuration...")
    logger.debug("This is a test debug message from logger.py (Loguru).")
    logger.info("This is a test info message from logger.py (Loguru).")
    logger.warning("This is a test warning message from logger.py (Loguru).")
    logger.error("This is a test error message from logger.py (Loguru).")
    logger.critical("This is a test critical message from logger.py (Loguru).")

    try:
        1 / 0
    except ZeroDivisionError:
        logger.exception("Caught an expected ZeroDivisionError.")

    if settings.log_dir:
        print(f"Check for Loguru log files in: {os.path.abspath(settings.log_dir)}")
    else:
        print("File logging was not configured for Loguru (LOG_DIR not set).")
    
    # To test uncaught exception:
    # raise RuntimeError("This is a test uncaught exception after Loguru setup.") 