"""
文件加载工具模块

用于从本地JSON文件加载应用配置数据
"""

import json
from pathlib import Path
from typing import Dict, Any, Optional

from utils.logger import logger


def load_init_data_from_file(file_path: str = "data/zhenghua.json") -> Optional[Dict[str, Any]]:
    """
    从JSON文件加载初始化数据
    
    Args:
        file_path: JSON文件路径，相对于项目根目录
        
    Returns:
        Dict[str, Any]: 解析后的JSON数据，失败时返回None
        
    Raises:
        FileNotFoundError: 文件不存在
        json.JSONDecodeError: JSON格式错误
        Exception: 其他读取错误
    """
    try:
        # 获取项目根目录
        current_dir = Path(__file__).parent.parent
        full_path = current_dir / file_path
        
        logger.info(f"Loading init data from file: {full_path}")
        
        # 检查文件是否存在
        if not full_path.exists():
            raise FileNotFoundError(f"Init data file not found: {full_path}")
        
        # 检查文件是否为空
        if full_path.stat().st_size == 0:
            raise ValueError(f"Init data file is empty: {full_path}")
        
        # 读取并解析JSON文件
        with open(full_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
        
        logger.info(f"Successfully loaded init data from file")
        logger.debug(f"Data contains: {len(data.get('agents', []))} agents, "
                    f"{len(data.get('intro_prompts', []))} prompts, "
                    f"{len(data.get('device_categories', []))} categories")
        
        return data
        
    except FileNotFoundError as e:
        logger.error(f"File not found: {e}")
        raise
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {e}")
        raise
        
    except Exception as e:
        logger.error(f"Error loading init data from file: {e}", exc_info=True)
        raise


def validate_init_data_structure(data: Dict[str, Any]) -> bool:
    """
    验证初始化数据结构的完整性
    
    Args:
        data: 待验证的数据字典
        
    Returns:
        bool: 数据结构是否有效
    """
    try:
        required_keys = ['agents', 'intro_prompts', 'device_categories', 'app_config']
        
        # 检查顶级键
        for key in required_keys:
            if key not in data:
                logger.error(f"Missing required key: {key}")
                return False
        
        # 检查agents结构
        agents = data.get('agents', [])
        if not isinstance(agents, list):
            logger.error("'agents' should be a list")
            return False
        
        for agent in agents:
            agent_required_keys = ['id', 'label', 'value', 'active', 'icon', 'description', 'system_message']
            for key in agent_required_keys:
                if key not in agent:
                    logger.error(f"Missing required key '{key}' in agent")
                    return False
        
        # 检查intro_prompts结构
        prompts = data.get('intro_prompts', [])
        if not isinstance(prompts, list):
            logger.error("'intro_prompts' should be a list")
            return False
        
        for prompt in prompts:
            prompt_required_keys = ['id', 'label', 'value', 'category', 'order']
            for key in prompt_required_keys:
                if key not in prompt:
                    logger.error(f"Missing required key '{key}' in intro_prompt")
                    return False
        
        # 检查device_categories结构
        categories = data.get('device_categories', [])
        if not isinstance(categories, list):
            logger.error("'device_categories' should be a list")
            return False
        
        for category in categories:
            category_required_keys = ['id', 'label', 'value', 'icon', 'description', 'questions']
            for key in category_required_keys:
                if key not in category:
                    logger.error(f"Missing required key '{key}' in device_category")
                    return False
            
            # 检查questions结构
            questions = category.get('questions', [])
            if not isinstance(questions, list):
                logger.error("'questions' should be a list")
                return False
            
            for question in questions:
                question_required_keys = ['id', 'label', 'value', 'severity', 'frequency', 'keywords']
                for key in question_required_keys:
                    if key not in question:
                        logger.error(f"Missing required key '{key}' in question")
                        return False
        
        # 检查app_config结构
        app_config = data.get('app_config', {})
        if not isinstance(app_config, dict):
            logger.error("'app_config' should be a dict")
            return False
        
        config_required_keys = ['avatars', 'ui_settings', 'api_settings', 'company_info']
        for key in config_required_keys:
            if key not in app_config:
                logger.error(f"Missing required key '{key}' in app_config")
                return False
        
        logger.info("Init data structure validation passed")
        return True
        
    except Exception as e:
        logger.error(f"Error validating init data structure: {e}", exc_info=True)
        return False 