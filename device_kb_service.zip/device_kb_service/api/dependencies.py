import asyncio
import secrets
import time
import uuid
from typing import Optional, Any  # Coroutine not needed for these functions

from fastapi import Request, HTTPException, status
from ragflow_sdk import RAGFlow

from config import settings  # Absolute import
from errors.handlers import create_openai_error_response_content
from utils.logger import logger  # Absolute import


# --- Request ID Generation Dependency ---
class RequestIDState:
    def __init__(self):
        self.last_request_time: float = 0.0
        self.request_counter: int = 0
        self.lock: asyncio.Lock = asyncio.Lock()

request_id_state = RequestIDState()

async def get_request_id(request: Request) -> str:
    """
    Generates a unique request ID in a format similar to OpenAI (chatcmpl-...). 
    """
    async with request_id_state.lock:
        current_time_seconds = time.time()
        if current_time_seconds == request_id_state.last_request_time:
            request_id_state.request_counter += 1
        else:
            request_id_state.request_counter = 0
            request_id_state.last_request_time = current_time_seconds

        unique_part = f"{int(current_time_seconds)}-{request_id_state.request_counter}"
        return f"chatcmpl-{str(uuid.uuid4())[:8]}-{unique_part}"

# --- API Key Verification Dependency ---
async def verify_api_key(request: Request):
    # Check if auth is required
    if not settings.require_auth:
        logger.debug("Authentication not required (REQUIRE_AUTH=False).")
        return None
        
    configured_key = settings.service_openai_api_key
    
    if not configured_key:
        # If no API key is configured for the service, skip auth.
        # This allows the service to run in an unprotected mode.
        logger.warning("API key not configured (SERVICE_OPENAI_API_KEY is not set). Skipping authentication.")
        return

    auth_header = request.headers.get("Authorization")
    if not auth_header:
        logger.warning("Missing Authorization header")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=create_openai_error_response_content(
                message="Missing Authorization header.",
                type_="authentication_error",
                code="missing_authorization_header"
            ),
            headers={"WWW-Authenticate": "Bearer"}
        )

    try:
        scheme, _, token = auth_header.partition(' ')
        if not scheme or scheme.lower() != 'bearer' or not token:
            logger.warning(f"Invalid Authorization header format: {auth_header}")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=create_openai_error_response_content(
                    message="Invalid Authorization header format. Expected 'Bearer <token>'.",
                    type_="authentication_error",
                    code="invalid_authorization_header"
                ),
                headers={"WWW-Authenticate": "Bearer"}
            )
    except ValueError:
        logger.warning(f"Malformed Authorization header: {auth_header}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=create_openai_error_response_content(
                message="Malformed Authorization header.",
                type_="authentication_error",
                code="malformed_authorization_header"
            ),
            headers={"WWW-Authenticate": "Bearer"}
        )
    
    # Securely compare the provided token with the configured key
    # .get_secret_value() is used because service_openai_api_key is SecretStr
    if not secrets.compare_digest(token.encode('utf-8'), configured_key.get_secret_value().encode('utf-8')):
        logger.warning("Invalid API key provided.")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, # Changed from 401 to 403 for invalid key after valid format
            detail=create_openai_error_response_content(
                message="Invalid API key.",
                type_="authentication_error",
                code="invalid_api_key"
            )
        )
    logger.debug("API key verified successfully.")

# --- Helper for RAGFlow from Request State ---
def get_ragflow_dependency(request: Request) -> RAGFlow:
    """
    Dependency to get the RAGFlow instance from the request state.
    
    Ensures RAGFlow is properly initialized and available for use.
    Provides detailed error information for debugging.
    """
    try:
        # Check if request.app.state exists
        if not hasattr(request.app, 'state'):
            logger.error("FastAPI app state not found in request context.")
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=create_openai_error_response_content(
                    message="Application state not properly initialized.",
                    type_="service_unavailable",
                    code="app_state_missing"
                )
            )
        
        # Check if ragflow exists in app state
        if not hasattr(request.app.state, 'ragflow'):
            logger.error("RAGFlow instance not found in application state.")
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=create_openai_error_response_content(
                    message="Knowledge base service is not configured. RAGFlow instance not initialized.",
                    type_="service_unavailable",
                    code="ragflow_not_configured"
                )
            )
        
        ragflow_instance = request.app.state.ragflow
        
        # Check if ragflow is None
        if ragflow_instance is None:
            logger.error("RAGFlow instance is None. Service may have failed to initialize.")
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=create_openai_error_response_content(
                    message="Knowledge base service failed to initialize properly.",
                    type_="service_unavailable", 
                    code="ragflow_initialization_failed"
                )
            )
        
        # Check if it's actually a RAGFlow instance
        if not isinstance(ragflow_instance, RAGFlow):
            logger.error(f"Invalid RAGFlow instance type: {type(ragflow_instance)}. Expected RAGFlow.")
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=create_openai_error_response_content(
                    message="Knowledge base service configuration error.",
                    type_="service_unavailable",
                    code="ragflow_invalid_instance"
                )
            )
        
        logger.debug("RAGFlow dependency successfully resolved.")
        return ragflow_instance
        
    except HTTPException:
        # Re-raise HTTP exceptions as-is
        raise
    except Exception as e:
        logger.error(f"Unexpected error retrieving RAGFlow dependency: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=create_openai_error_response_content(
                message="Knowledge base service is currently unavailable due to an internal error.",
                type_="service_unavailable",
                code="ragflow_dependency_error"
            )
        ) 

def get_ragflow_service_dependency(request: Request) -> 'RagFlowService':
    """
    Dependency to get the RagFlow service instance from the request state.
    
    Returns a business service layer instance that encapsulates RagFlow operations.
    Provides better abstraction and testability compared to direct RAGFlow usage.
    """
    from core.ragflow_service import RagFlowService
    
    try:
        # Get the RAGFlow client first
        ragflow_client = get_ragflow_dependency(request)
        
        # Check if we already have a service instance in app state
        if not hasattr(request.app.state, 'ragflow_service'):
            logger.debug("Creating new RagFlow service instance.")
            ragflow_service = RagFlowService(ragflow_client)
            request.app.state.ragflow_service = ragflow_service
        else:
            ragflow_service = request.app.state.ragflow_service
            logger.debug("Using existing RagFlow service instance.")
        
        return ragflow_service
        
    except HTTPException:
        # Re-raise HTTP exceptions from get_ragflow_dependency
        raise
    except Exception as e:
        logger.error(f"Unexpected error creating RagFlow service: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=create_openai_error_response_content(
                message="Knowledge base service layer is currently unavailable.",
                type_="service_unavailable",
                code="ragflow_service_error"
            )
        ) 