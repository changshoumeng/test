# 设备知识库服务API文档

## 服务概述

设备知识库服务（Device KB Service）为"设备排故AI专家"提供OpenAI兼容的API接口，集成RagFlow知识库，专注于振华重工吊具设备的故障诊断和技术支持。

本服务采用极简化API设计，通过聚合初始化接口实现高效的数据获取，智能推荐功能集成在聊天接口中。

## 基础配置

### 服务地址

```
http://localhost:8089/device_kb/v1
```

### 认证方式

服务支持可选的Bearer Token认证。在环境变量中设置`REQUIRE_AUTH=true`启用认证功能。

启用认证时，请在请求头中包含API密钥：

```
Authorization: Bearer YOUR_API_KEY
```

## API接口

### 1. 应用初始化

获取应用所需的全部配置数据，包括助手列表、引导提示、设备分类、故障问题和应用配置。

**接口地址：** `GET /device_kb/v1/init`

**查询参数：**
- `version` (字符串，可选): 客户端缓存版本，用于缓存验证

**响应：**

```json
{
  "object": "init_data",
  "version": "1.0.2",
  "timestamp": 1677858242,
  "data": {
    "agents": [
      {
        "id": "general-expert",
        "label": "通用助手",
        "value": "general-expert",
        "active": true,
        "icon": "/master-logo-50.png",
        "description": "振华重工设备排故AI专家，提供全面的设备故障诊断和技术支持",
        "system_message": "你是振华重工旗下的设备排故AI专家，专门为振华重工的吊具设备提供专业的故障诊断、排除指导、设备维护、程序调试和性能优化服务。你具备深厚的工程技术背景，熟悉各类吊具设备的工作原理、常见故障模式和维修方法。"
      },
      {
        "id": "electrical-expert",
        "label": "电气设备排故助手",
        "value": "electrical-expert",
        "active": false,
        "icon": "/electrical-icon.png",
        "description": "专精于电气系统故障诊断，包括编码器、传感器、继电器等电气元件",
        "system_message": "你是振华重工旗下的电气设备排故助手，专精于吊具电气系统的故障诊断和维修。你对电动机、编码器、传感器、继电器、变频器等电气元件有深入理解，能够快速定位电气故障并提供专业的解决方案。"
      },
      {
        "id": "mechanical-expert",
        "label": "机械设备排故助手",
        "value": "mechanical-expert",
        "active": false,
        "icon": "/mechanical-icon.png",
        "description": "专精于机械结构故障诊断，包括伸缩机构、旋转机构等机械部件",
        "system_message": "你是振华重工旗下的机械设备排故助手，专精于吊具机械结构的故障诊断和维护。你对伸缩机构、旋转机构、液压系统、传动装置等机械部件有深入理解，能够识别机械故障并提供有效的维修指导。"
      }
    ],
    "intro_prompts": [
      {
        "id": "quick_diagnosis",
        "label": "快速诊断设备故障",
        "value": "我的吊具设备出现了故障，请帮我进行快速诊断和分析",
        "category": "diagnosis",
        "order": 1
      },
      {
        "id": "fault_procedure",
        "label": "查看故障排除步骤",
        "value": "请介绍振华重工吊具设备故障的标准排除步骤和流程",
        "category": "procedure",
        "order": 2
      },
      {
        "id": "maintenance_guide",
        "label": "设备维护保养指导",
        "value": "如何做好振华重工吊具设备的日常维护和保养？",
        "category": "maintenance",
        "order": 3
      },
      {
        "id": "program_debug",
        "label": "程序调试与优化",
        "value": "设备控制程序出现问题，需要调试和优化建议",
        "category": "programming",
        "order": 4
      }
    ],
    "device_categories": [
      {
        "id": "electric-single-spreader",
        "label": "电动单箱吊具",
        "value": "electric-single-spreader",
        "icon": "🔌",
        "description": "电动机、导板、编码器、继电器等电气故障",
        "questions": [
          {
            "id": "spreader_no_extend",
            "label": "吊具无法伸缩",
            "value": "电动单箱吊具无法伸缩，可能的原因和解决方案是什么？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["伸缩", "电动机", "控制系统"]
          },
          {
            "id": "motor_not_running",
            "label": "电动机不转",
            "value": "电动单箱吊具的电动机不转，如何排查电气故障？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["电动机", "电气故障", "电源"]
          },
          {
            "id": "encoder_error",
            "label": "编码器报警",
            "value": "电动单箱吊具编码器出现报警，应该如何处理？",
            "severity": "medium",
            "frequency": "common",
            "keywords": ["编码器", "报警", "位置反馈"]
          },
          {
            "id": "relay_failure",
            "label": "继电器故障",
            "value": "电动单箱吊具的继电器出现故障，如何检测和更换？",
            "severity": "medium",
            "frequency": "occasional",
            "keywords": ["继电器", "控制回路", "开关"]
          },
          {
            "id": "guide_plate_stuck",
            "label": "导板卡死",
            "value": "电动单箱吊具的导板出现卡死现象，如何解决？",
            "severity": "high",
            "frequency": "occasional",
            "keywords": ["导板", "卡死", "机械"]
          },
          {
            "id": "power_supply_issue",
            "label": "供电异常",
            "value": "电动单箱吊具供电系统出现异常，如何排查？",
            "severity": "high",
            "frequency": "occasional",
            "keywords": ["供电", "电源", "电压"]
          },
          {
            "id": "control_signal_loss",
            "label": "控制信号丢失",
            "value": "电动单箱吊具控制信号丢失，无法正常操作怎么办？",
            "severity": "high",
            "frequency": "rare",
            "keywords": ["控制信号", "通信", "操作"]
          }
        ]
      },
      {
        "id": "hydraulic-rotating-spreader",
        "label": "液压旋转吊具",
        "value": "hydraulic-rotating-spreader",
        "icon": "🔄",
        "description": "自动调平、旋转控制、液压系统等故障",
        "questions": [
          {
            "id": "auto_level_malfunction",
            "label": "自动调平失效",
            "value": "液压旋转吊具的自动调平功能失效，应该如何处理？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["自动调平", "液压", "传感器"]
          },
          {
            "id": "rotation_stuck",
            "label": "旋转机构卡死",
            "value": "液压旋转吊具的旋转机构出现卡死，如何解决？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["旋转", "卡死", "液压马达"]
          },
          {
            "id": "hydraulic_leak",
            "label": "液压系统漏油",
            "value": "液压旋转吊具液压系统出现漏油，如何定位和修复？",
            "severity": "medium",
            "frequency": "common",
            "keywords": ["液压", "漏油", "密封件"]
          },
          {
            "id": "pressure_insufficient",
            "label": "液压压力不足",
            "value": "液压旋转吊具压力不足，无法正常工作怎么办？",
            "severity": "high",
            "frequency": "occasional",
            "keywords": ["液压压力", "泵站", "压力表"]
          },
          {
            "id": "hydraulic_motor_failure",
            "label": "液压马达故障",
            "value": "液压旋转吊具的液压马达出现故障，如何诊断？",
            "severity": "high",
            "frequency": "occasional",
            "keywords": ["液压马达", "故障", "旋转"]
          },
          {
            "id": "control_valve_stuck",
            "label": "控制阀卡死",
            "value": "液压旋转吊具的控制阀出现卡死，如何处理？",
            "severity": "medium",
            "frequency": "rare",
            "keywords": ["控制阀", "卡死", "液压回路"]
          }
        ]
      },
      {
        "id": "hydraulic-mobile-dual-spreader",
        "label": "液压移动双箱吊具",
        "value": "hydraulic-mobile-dual-spreader",
        "icon": "📦",
        "description": "双箱控制、移动机构、液压驱动等故障",
        "questions": [
          {
            "id": "dual_box_sync_error",
            "label": "双箱同步异常",
            "value": "液压移动双箱吊具的双箱同步出现异常，如何调整？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["双箱", "同步", "控制"]
          },
          {
            "id": "mobile_mechanism_stuck",
            "label": "移动机构卡死",
            "value": "液压移动双箱吊具的移动机构卡死，无法移动怎么办？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["移动机构", "卡死", "导轨"]
          },
          {
            "id": "hydraulic_drive_failure",
            "label": "液压驱动故障",
            "value": "液压移动双箱吊具的液压驱动系统故障，如何排查？",
            "severity": "high",
            "frequency": "occasional",
            "keywords": ["液压驱动", "故障", "动力"]
          },
          {
            "id": "position_sensor_error",
            "label": "位置传感器异常",
            "value": "液压移动双箱吊具位置传感器出现异常，如何校准？",
            "severity": "medium",
            "frequency": "occasional",
            "keywords": ["位置传感器", "异常", "校准"]
          },
          {
            "id": "guide_rail_wear",
            "label": "导轨磨损",
            "value": "液压移动双箱吊具导轨出现磨损，如何维护？",
            "severity": "medium",
            "frequency": "occasional",
            "keywords": ["导轨", "磨损", "维护"]
          },
          {
            "id": "hydraulic_cylinder_leak",
            "label": "液压缸泄漏",
            "value": "液压移动双箱吊具液压缸出现泄漏，如何处理？",
            "severity": "medium",
            "frequency": "rare",
            "keywords": ["液压缸", "泄漏", "密封"]
          }
        ]
      },
      {
        "id": "electric-dual-spreader",
        "label": "电动双箱吊具",
        "value": "electric-dual-spreader",
        "icon": "⚡",
        "description": "双电机控制、同步系统、电气驱动等故障",
        "questions": [
          {
            "id": "dual_motor_sync_error",
            "label": "双电机同步异常",
            "value": "电动双箱吊具的双电机同步出现异常，如何调整？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["双电机", "同步", "控制器"]
          },
          {
            "id": "motor_overload",
            "label": "电机过载保护",
            "value": "电动双箱吊具电机出现过载保护，如何处理？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["电机", "过载", "保护"]
          },
          {
            "id": "frequency_converter_alarm",
            "label": "变频器报警",
            "value": "电动双箱吊具变频器出现报警，如何诊断和处理？",
            "severity": "medium",
            "frequency": "common",
            "keywords": ["变频器", "报警", "参数"]
          },
          {
            "id": "electrical_control_failure",
            "label": "电气控制故障",
            "value": "电动双箱吊具电气控制系统故障，如何排查？",
            "severity": "high",
            "frequency": "occasional",
            "keywords": ["电气控制", "故障", "PLC"]
          },
          {
            "id": "encoder_sync_error",
            "label": "编码器同步异常",
            "value": "电动双箱吊具编码器同步异常，如何校准？",
            "severity": "medium",
            "frequency": "occasional",
            "keywords": ["编码器", "同步", "校准"]
          },
          {
            "id": "power_distribution_issue",
            "label": "配电系统异常",
            "value": "电动双箱吊具配电系统出现异常，如何检查？",
            "severity": "high",
            "frequency": "rare",
            "keywords": ["配电", "异常", "电源"]
          }
        ]
      },
      {
        "id": "analog-box",
        "label": "模拟箱",
        "value": "analog-box",
        "icon": "📱",
        "description": "模拟系统、训练模式、仿真控制等问题",
        "questions": [
          {
            "id": "simulation_system_error",
            "label": "模拟系统异常",
            "value": "模拟箱的模拟系统出现异常，无法正常运行怎么办？",
            "severity": "medium",
            "frequency": "common",
            "keywords": ["模拟系统", "异常", "仿真"]
          },
          {
            "id": "training_mode_failure",
            "label": "训练模式故障",
            "value": "模拟箱训练模式出现故障，如何重置和修复？",
            "severity": "medium",
            "frequency": "common",
            "keywords": ["训练模式", "故障", "重置"]
          },
          {
            "id": "display_malfunction",
            "label": "显示屏故障",
            "value": "模拟箱显示屏出现故障或显示异常，如何处理？",
            "severity": "medium",
            "frequency": "occasional",
            "keywords": ["显示屏", "故障", "显示"]
          },
          {
            "id": "control_panel_unresponsive",
            "label": "控制面板无响应",
            "value": "模拟箱控制面板无响应，按键失效怎么办？",
            "severity": "high",
            "frequency": "occasional",
            "keywords": ["控制面板", "无响应", "按键"]
          },
          {
            "id": "software_crash",
            "label": "软件崩溃",
            "value": "模拟箱软件系统崩溃或卡死，如何恢复？",
            "severity": "high",
            "frequency": "occasional",
            "keywords": ["软件", "崩溃", "恢复"]
          },
          {
            "id": "data_connection_lost",
            "label": "数据连接中断",
            "value": "模拟箱与主系统的数据连接中断，如何重新建立？",
            "severity": "medium",
            "frequency": "rare",
            "keywords": ["数据连接", "中断", "通信"]
          }
        ]
      },
      {
        "id": "control-cabinet-others",
        "label": "控制电箱及其他",
        "value": "control-cabinet-others",
        "icon": "🔧",
        "description": "控制柜、配电、通信系统等其他设备故障",
        "questions": [
          {
            "id": "control_cabinet_overheating",
            "label": "控制柜过热",
            "value": "控制电箱出现过热现象，散热系统异常如何处理？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["控制柜", "过热", "散热"]
          },
          {
            "id": "power_distribution_fault",
            "label": "配电故障",
            "value": "控制电箱配电系统出现故障，如何排查和修复？",
            "severity": "high",
            "frequency": "common",
            "keywords": ["配电", "故障", "电路"]
          },
          {
            "id": "communication_error",
            "label": "通信异常",
            "value": "控制系统通信出现异常，设备无法正常通讯怎么办？",
            "severity": "high",
            "frequency": "occasional",
            "keywords": ["通信", "异常", "网络"]
          },
          {
            "id": "plc_program_error",
            "label": "PLC程序错误",
            "value": "控制电箱PLC程序出现错误，如何诊断和修复？",
            "severity": "medium",
            "frequency": "occasional",
            "keywords": ["PLC", "程序", "错误"]
          },
          {
            "id": "electrical_component_aging",
            "label": "电气元件老化",
            "value": "控制电箱内电气元件老化，如何预防性维护？",
            "severity": "medium",
            "frequency": "occasional",
            "keywords": ["电气元件", "老化", "维护"]
          },
          {
            "id": "grounding_system_issue",
            "label": "接地系统问题",
            "value": "控制电箱接地系统出现问题，如何检测和处理？",
            "severity": "medium",
            "frequency": "rare",
            "keywords": ["接地", "系统", "安全"]
          }
        ]
      }
    ],
    "app_config": {
      "avatars": {
        "ai_default": {
          "imgSrc": "/master-logo-50.png",
          "width": 32,
          "height": 32
        },
        "user_default": {
          "imgSrc": "https://matechat.gitcode.com/png/demo/userAvatar.svg",
          "width": 32,
          "height": 32
        }
      },
      "ui_settings": {
        "theme": "light",
        "categories_per_page": 3,
        "questions_per_toolbar": 4,
        "questions_per_guess": 12
      },
      "api_settings": {
        "default_model": "device_fault_master",
        "temperature": 0.7,
        "stream": true
      },
      "company_info": {
        "name": "振华重工",
        "product_name": "设备排故AI专家",
        "logo": "/master-logo-50.png"
      }
    }
  }
}
```

### 2. 聊天对话

为给定的聊天对话创建AI模型响应，智能推荐功能集成在流式响应中。

**接口地址：** `POST /device_kb/v1/chat/completions`

**请求体：**

```json
{
  "model": "device_fault_master",
  "messages": [
    {
      "role": "user",
      "content": "设备X的维护流程是什么？"
    }
  ],
  "temperature": 0.7,
  "stream": false,
  "user": "user123"
}
```

**请求参数：**

- `model` (字符串，可选): 使用的模型，默认为配置的默认模型
- `messages` (数组，必需): 包含`role`和`content`的消息对象数组
  - `role`: "system"、"user"或"assistant"之一
  - `content`: 消息内容（字符串或内容部分数组）
- `temperature` (数字，可选): 采样温度，范围0-2
- `stream` (布尔值，可选): 是否流式返回响应，默认false
- `user` (字符串，可选): 最终用户的唯一标识符

**响应（非流式）：**

```json
{
  "id": "chatcmpl-abc123",
  "object": "chat.completion",
  "created": 1677858242,
  "model": "device_fault_master",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "设备X的维护流程包括..."
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 13,
    "completion_tokens": 125,
    "total_tokens": 138
  },
  "system_fingerprint": "fp_44709d6f"
}
```

**响应（流式）：**

当`stream: true`时，响应以Server-Sent Events（SSE）格式发送，最后包含智能推荐：

```
data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1677858242,"model":"device_fault_master","choices":[{"index":0,"delta":{"role":"assistant","content":"设备"},"finish_reason":null}]}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1677858242,"model":"device_fault_master","choices":[{"index":0,"delta":{"content":"X的维护"},"finish_reason":null}]}

data: {"id":"chatcmpl-abc123","object":"chat.completion.chunk","created":1677858242,"model":"device_fault_master","choices":[{"index":0,"delta":{"content":"{\"guess\":[\"如何清洁室外机散热片？\",\"制冷剂是否可能不足？\",\"压缩机是否需要更换？\",\"需要请专业师傅检查吗？\",\"大概多长时间能修好？\"]}"},"finish_reason":"stop"}]}

data: [DONE]
```

### 3. 模型列表

获取当前可用的模型列表。

**接口地址：** `GET /device_kb/v1/models`

**响应：**

```json
{
  "object": "list",
  "data": [
    {
      "id": "device_fault_master",
      "object": "model",
      "created": 1677858242,
      "owned_by": "device_kb_service"
    }
  ]
}
```

## 错误处理

API采用OpenAI兼容的错误格式：

```json
{
  "error": {
    "message": "输入验证错误：'messages'不能为空",
    "type": "invalid_request_error",
    "param": "messages",
    "code": null
  }
}
```

**常见错误类型：**

- `invalid_request_error`: 请求参数无效
- `authentication_error`: 认证失败
- `api_error`: 服务器端错误
- `rate_limit_error`: 请求频率超限
- `not_found_error`: 资源不存在

**HTTP状态码：**

- `200`: 请求成功
- `400`: 请求参数错误
- `401`: 认证失败
- `404`: 资源不存在
- `429`: 请求频率超限
- `500`: 服务器内部错误

## SDK兼容性

本API完全兼容OpenAI Python SDK：

```python
from openai import OpenAI

client = OpenAI(
    api_key="your-api-key",
    base_url="http://localhost:8089/device_kb/v1"
)

# 聊天对话
response = client.chat.completions.create(
    model="device_fault_master",
    messages=[
        {"role": "user", "content": "请介绍设备维护流程"}
    ]
)

print(response.choices[0].message.content)
```

## 前端集成示例

### Vue 3 集成示例

```javascript
// composables/useAppInit.ts
import { ref, onMounted } from 'vue';

export function useAppInit() {
  const loading = ref(true);
  const error = ref(null);
  const appData = ref(null);
  
  const initializeApp = async () => {
    try {
      loading.value = true;
      error.value = null;
      
      const response = await fetch('/device_kb/v1/init');
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      const data = await response.json();
      appData.value = data.data;
      
      // 缓存数据和版本
      localStorage.setItem('app_data_version', data.version);
      localStorage.setItem('app_data_cache', JSON.stringify(data.data));
      
    } catch (err) {
      error.value = err.message;
      console.error('应用初始化失败:', err);
    } finally {
      loading.value = false;
    }
  };
  
  // 检查缓存，实现快速启动
  const checkCache = () => {
    const cachedData = localStorage.getItem('app_data_cache');
    if (cachedData) {
      try {
        appData.value = JSON.parse(cachedData);
        loading.value = false;
        // 后台检查更新
        checkForUpdates();
      } catch (err) {
        console.warn('缓存数据解析失败:', err);
        initializeApp();
      }
    } else {
      initializeApp();
    }
  };
  
  const checkForUpdates = async () => {
    const cachedVersion = localStorage.getItem('app_data_version');
    if (!cachedVersion) return;
    
    try {
      const response = await fetch(`/device_kb/v1/init?version=${cachedVersion}`);
      const data = await response.json();
      
      if (data.version !== cachedVersion) {
        appData.value = data.data;
        localStorage.setItem('app_data_version', data.version);
        localStorage.setItem('app_data_cache', JSON.stringify(data.data));
      }
    } catch (err) {
      console.warn('检查更新失败:', err);
    }
  };
  
  onMounted(() => {
    checkCache();
  });
  
  return {
    loading: readonly(loading),
    error: readonly(error),
    appData: readonly(appData),
    initializeApp
  };
}

// 在组件中使用
export default defineComponent({
  setup() {
    const { loading, error, appData } = useAppInit();
    
    const agents = computed(() => appData.value?.agents || []);
    const introPrompts = computed(() => appData.value?.intro_prompts || []);
    const deviceCategories = computed(() => appData.value?.device_categories || []);
    const appConfig = computed(() => appData.value?.app_config || {});
    
    return {
      loading,
      error,
      agents,
      introPrompts,
      deviceCategories,
      appConfig
    };
  }
});
```

## 更新日志

- **v1.0.0**: 极简化API设计，只保留3个核心接口
- **v1.1.0**: 优化缓存策略，支持版本控制
- **v1.2.0**: 智能推荐集成到聊天接口中
