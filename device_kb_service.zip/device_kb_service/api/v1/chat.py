import json
import time
import uuid
from typing import AsyncGenerator, List, Dict, Union, Any, Optional, Generator

from fastapi import APIRouter, Request, Depends, HTTPException, status
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel, Field

from device_kb_service.config import settings
from device_kb_service.utils.logger import logger
from device_kb_service.core.models import ChatCompletionRequest, ChatMessage
from device_kb_service.core.ragflow_service import RagFlowService
from device_kb_service.core.ollama_service import ollama_service
from device_kb_service.api.dependencies import get_request_id, verify_api_key, get_ragflow_service_dependency
from device_kb_service.errors.exceptions import RagFlowAPIException, SessionError, RagFlowUnexpectedError
from device_kb_service.errors.handlers import create_openai_error_response_content

# --- OpenAI Response Models ---
class OpenAIDelta(BaseModel):
    role: Optional[str] = "assistant"
    content: Optional[str] = None

class OpenAIResponseChoiceChunk(BaseModel):
    index: int
    delta: OpenAIDelta
    finish_reason: Optional[str] = None
    logprobs: Optional[Any] = None

class OpenAIChatCompletionChunkResponse(BaseModel):
    id: str
    object: str = Field(default="chat.completion.chunk")
    created: int
    model: str
    choices: List[OpenAIResponseChoiceChunk]
    system_fingerprint: Optional[str] = None

class OpenAIResponseMessage(BaseModel):
    role: str = "assistant"
    content: Optional[str] = None

class OpenAIResponseChoice(BaseModel):
    index: int
    message: OpenAIResponseMessage
    finish_reason: Optional[str] = None
    logprobs: Optional[Any] = None

class OpenAIUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int

class OpenAIChatCompletionResponse(BaseModel):
    id: str
    object: str = Field(default="chat.completion")
    created: int
    model: str
    choices: List[OpenAIResponseChoice]
    usage: Optional[OpenAIUsage] = None
    system_fingerprint: Optional[str] = None

router = APIRouter()

def _content_to_str(raw_content: Optional[Union[str, List[Dict[str, Any]]]]) -> str:
    """Convert OpenAI content field to pure string."""
    if raw_content is None:
        return ""
    if isinstance(raw_content, str):
        return raw_content
    # Handle list[{"type":"text","text":...}] format
    if isinstance(raw_content, list):
        try:
            return "".join(segment.get("text", "") for segment in raw_content if isinstance(segment, dict))
        except Exception:
            return str(raw_content)
    return str(raw_content)

def _extract_user_message(messages: List[ChatMessage]) -> str:
    """Extract the latest user message from the conversation."""
    for msg in reversed(messages):
        if msg.role == 'user':
            return _content_to_str(msg.content)
    return ""

def _validate_chat_request(request_payload: ChatCompletionRequest, request_id: str) -> str:
    """Validate chat completion request and extract user message."""
    if not request_payload.messages:
        logger.warning(f"RID: {request_id} - Validation Error: Messages list is empty.")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=create_openai_error_response_content(
                message="Input validation error: 'messages' must not be empty.",
                type_="invalid_request_error",
                param="messages"
            )
        )
    
    user_message = _extract_user_message(request_payload.messages)
    if not user_message:
        logger.warning(f"RID: {request_id} - Validation Error: No user message found.")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=create_openai_error_response_content(
                message="Input validation error: 'messages' must contain at least one 'user' role message.",
                type_="invalid_request_error",
                param="messages"
            )
        )
    
    return user_message

def _build_openai_chunk(request_id: str, created_time: int, model: str, 
                       system_fingerprint: str, delta: OpenAIDelta = None, 
                       finish_reason: str = None) -> str:
    """Build OpenAI-compatible streaming chunk."""
    if delta is None:
        delta = OpenAIDelta(content=None)
    
    choice = OpenAIResponseChoiceChunk(
        index=0, 
        delta=delta, 
        finish_reason=finish_reason
    )
    chunk = OpenAIChatCompletionChunkResponse(
        id=request_id,
        created=created_time,
        model=model,
        choices=[choice],
        system_fingerprint=system_fingerprint
    )
    return f"data: {chunk.model_dump_json(exclude_none=True)}\n\n"

def _build_openai_response(request_id: str, model: str, content: str, user_message: str = "") -> Dict[str, Any]:
    """Build OpenAI-compatible non-streaming response."""
    response_message = OpenAIResponseMessage(
        role="assistant",
        content=content
    )
    
    # Estimate token usage
    prompt_tokens = len(user_message) // 4  # Rough estimate based on user input
    completion_tokens = len(content) // 4   # Based on AI response
    
    usage = OpenAIUsage(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=prompt_tokens + completion_tokens
    )
    
    response_choice = OpenAIResponseChoice(
        index=0,
        message=response_message,
        finish_reason="stop"
    )
    
    final_response = OpenAIChatCompletionResponse(
        id=request_id,
        created=int(time.time()),
        model=model,
        choices=[response_choice],
        usage=usage,
        system_fingerprint=f"fp_{str(uuid.uuid4())[:8]}"
    )
    
    return final_response.model_dump(exclude_none=True)

def _convert_messages_for_ollama(messages: List[ChatMessage]) -> List[Dict[str, str]]:
    """Convert ChatMessage objects to dict format for ollama_service."""
    last_messages = []
    for msg in messages[-5:]:  # 取最后5条消息
        content_str = ""
        if isinstance(msg.content, str):
            content_str = msg.content
        elif isinstance(msg.content, list):
            # Handle list content format
            content_str = "".join(segment.get("text", "") for segment in msg.content if isinstance(segment, dict))
        
        last_messages.append({
            "role": msg.role,
            "content": content_str
        })
    return last_messages

async def _generate_guess_questions_json(messages: List[ChatMessage], request_id: str) -> Optional[str]:
    """Generate 'guess what you want to ask' questions and return as JSON string."""
    try:
        logger.debug(f"RID: {request_id} - 开始生成猜你想问问题")
        
        # Convert ChatMessage objects to dict format for ollama_service
        last_messages = _convert_messages_for_ollama(messages)
        
        # Call ollama service to generate questions
        predicted_questions = await ollama_service.guess_next_questions(last_messages)
        
        # Build guess result JSON
        guess_result = {"guess": predicted_questions}
        guess_json = json.dumps(guess_result, ensure_ascii=False)
        
        logger.info(f"RID: {request_id} - 猜你想问生成完成: {predicted_questions}")
        return guess_json
        
    except Exception as guess_e:
        logger.error(f"RID: {request_id} - 猜你想问功能异常: {guess_e}")
        return None

async def _handle_streaming_response(ragflow_service: RagFlowService, session_key: str, 
                                   user_message: str, request_id: str, model: str, messages: List[ChatMessage]) -> AsyncGenerator[str, None]:
    """Handle streaming chat completion response."""
    created_time = int(time.time())
    system_fingerprint = f"fp_{str(uuid.uuid4())[:8]}"
    
    # Send initial chunk with role
    initial_delta = OpenAIDelta(role="assistant", content=None)
    yield _build_openai_chunk(request_id, created_time, model, system_fingerprint, initial_delta)
    
    try:
        # Get session and send message using the optimized stream method
        session = ragflow_service.get_or_create_session(session_key)
        
        # Use the new stream method that returns tuple of (delta_content, references)
        references = []  # 存储引用信息
        for response_data in ragflow_service.send_message_stream(session=session, message=user_message):
            delta_content, refs = response_data  # 解包元组
            
            if delta_content:  # Only send non-empty deltas
                # Send delta chunk
                delta = OpenAIDelta(content=delta_content)
                yield _build_openai_chunk(request_id, created_time, model, system_fingerprint, delta)
            
            # 如果有引用信息，更新引用列表
            if refs:
                references = refs
                logger.debug(f"RID: {request_id} - 收到{len(refs)}条引用信息")
        
        # Generate "猜你想问" questions before sending finish chunk
        guess_json = await _generate_guess_questions_json(messages, request_id)
        
        # 构建包含引用信息的响应
        response_data = {}
        
        # 如果有引用信息，将其包含在响应中
        if references:
            # 直接传递ragflow的原始引用数据，让前端处理格式适配
            references_info = {
                "references": references  # 直接使用原始引用数据
            }
            response_data.update(references_info)
        
        # 如果有猜你想问，也包含在响应中
        if guess_json:
            # 解析猜你想问的JSON
            try:
                import json as json_lib
                guess_data = json_lib.loads(guess_json)
                response_data.update(guess_data)
            except:
                # 如果解析失败，直接使用原始字符串
                response_data["guessQuestions"] = []
        
        # 发送包含所有信息的finish chunk
        if response_data:
            finish_content = json.dumps(response_data, ensure_ascii=False)
            finish_delta = OpenAIDelta(content=finish_content)
            yield _build_openai_chunk(request_id, created_time, model, system_fingerprint, 
                                    finish_delta, finish_reason="stop")
        else:
            # 如果没有额外信息，发送普通的finish chunk
            yield _build_openai_chunk(request_id, created_time, model, system_fingerprint, 
                                    finish_reason="stop")
        
    except Exception as e:
        logger.error(f"RID: {request_id} - Error during stream: {e}", exc_info=True)
        # Invalidate session on error
        ragflow_service.invalidate_session(session_key)
        raise
    finally:
        yield "data: [DONE]\n\n"
        logger.info(f"RID: {request_id} - Stream finished.")

def _handle_non_streaming_response(ragflow_service: RagFlowService, session_key: str,
                                 user_message: str, request_id: str, model: str) -> Dict[str, Any]:
    """Handle non-streaming chat completion response."""
    try:
        # Get session and send message using the dedicated non-streaming method
        session = ragflow_service.get_or_create_session(session_key)
        
        # Use the new non-streaming method that directly returns complete content
        full_response = ragflow_service.send_message(session=session, message=user_message)
        
        logger.info(f"RID: {request_id} - Non-stream response completed. Content length: {len(full_response)}")
        return _build_openai_response(request_id, model, full_response, user_message)
        
    except Exception as e:
        logger.error(f"RID: {request_id} - Error during non-stream: {e}", exc_info=True)
        # Invalidate session on error
        ragflow_service.invalidate_session(session_key)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=create_openai_error_response_content(
                message="An unexpected error occurred while processing your request.",
                type_="internal_error"
            )
        )

@router.post("/chat/completions",
             response_model=None,
             responses={
                 200: {
                     "content": {
                         "application/json": {},
                         "text/event-stream": {}
                     },
                     "description": "Successful Response"
                 },
                 400: {"description": "Bad Request"},
                 401: {"description": "Unauthorized"},
                 429: {"description": "Rate Limit Exceeded"},
                 500: {"description": "Internal Server Error"}
             },
             summary="Creates a model response for the given chat conversation.",
             tags=["Chat Completions"])
async def chat_completions_endpoint(
    request_payload: ChatCompletionRequest,
    request: Request,
    request_id: str = Depends(get_request_id),
    ragflow_service: RagFlowService = Depends(get_ragflow_service_dependency),
    _api_key_verified: Optional[str] = Depends(verify_api_key)
):
    """
    Creates a model response for the given chat conversation.
    Supports both streaming and non-streaming responses.
    """
    model_to_use = request_payload.model or settings.default_model
    client_ip = request.client.host if request.client else "unknown"
    
    logger.info(f"RID: {request_id} - Path: /chat/completions - IP: {client_ip} - Model: {model_to_use} - Stream: {request_payload.stream}")
    
    # Validate request and extract user message
    user_message = _validate_chat_request(request_payload, request_id)
    
    # Create session key
    user_id = request_payload.user or f"user_{client_ip}"
    session_key = f"{user_id}_{model_to_use}"
    
    try:
        if request_payload.stream:
            logger.debug(f"RID: {request_id} - Initiating stream response.")
            stream_gen = _handle_streaming_response(ragflow_service, session_key, user_message, 
                                                  request_id, model_to_use, request_payload.messages)
            return StreamingResponse(stream_gen, media_type="text/event-stream")
        else:
            logger.debug(f"RID: {request_id} - Initiating non-stream response.")
            response_data = _handle_non_streaming_response(ragflow_service, session_key, user_message, 
                                                         request_id, model_to_use)
            return JSONResponse(content=response_data)
    
    except SessionError as e:
        logger.error(f"RID: {request_id} - Session error: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=create_openai_error_response_content(
                message=str(e),
                type_="invalid_request_error",
                code="session_error"
            )
        )
    except RagFlowAPIException as e:
        logger.error(f"RID: {request_id} - RagFlow API error: {e}", exc_info=True)
        raise HTTPException(
            status_code=e.status_code if e.status_code else 500,
            detail=create_openai_error_response_content(
                message=str(e),
                type_="api_error",
                code=e.code or "ragflow_error"
            )
        )
    except Exception as e:
        logger.error(f"RID: {request_id} - Unexpected error: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=create_openai_error_response_content(
                message="An unexpected internal server error occurred.",
                type_="internal_error"
            )
        ) 