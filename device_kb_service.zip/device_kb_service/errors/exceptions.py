from typing import Optional, Dict, Any

class RagFlowAPIException(Exception):
    """Base exception for RagFlow API related errors."""
    def __init__(self, message: str, status_code: int = 500, code: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.status_code = status_code
        self.code = code
        self.details = details
        super().__init__(self.message)

    def __str__(self) -> str:
        return f"RagFlowAPIException: {self.message} (Status: {self.status_code}, Code: {self.code}, Details: {self.details})"

class RagFlowRequestError(RagFlowAPIException):
    """Indicates an error during the request formation or network communication (pre-response)."""
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, status_code=503, code="request_error", details=details)

class RagFlowHTTPError(RagFlowAPIException):
    """Indicates an HTTP error response from the RagFlow API (e.g., 4xx, 5xx from RagFlow)."""
    def __init__(self, message: str, status_code: int, code: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, status_code=status_code, code=code, details=details)

class RagFlowUnexpectedError(RagFlowAPIException):
    """Indicates an unexpected error during processing, not directly an API or HTTP error."""
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, status_code=500, code="unexpected_error", details=details)

class RagFlowConcurrentLimitError(RagFlowAPIException):
    """Specific error for when the RagFlow API reports a concurrent request limit has been exceeded."""
    def __init__(self, message: str, retry_after: int = 2, details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, status_code=429, code="concurrent_limit_exceeded", details=details)
        self.retry_after = retry_after

class AuthenticationError(RagFlowAPIException):
    """Indicates an authentication failure with the RagFlow API."""
    def __init__(self, message: str = "Authentication failed with RagFlow API", details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, status_code=401, code="ragflow_auth_error", details=details)

class SessionError(RagFlowAPIException):
    """Indicates an error related to RagFlow session management."""
    def __init__(self, message: str = "RagFlow session error", details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, status_code=400, code="ragflow_session_error", details=details)

class KnowledgeBaseError(RagFlowAPIException):
    """Indicates an error related to RagFlow knowledge base operations."""
    def __init__(self, message: str = "RagFlow knowledge base error", details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, status_code=500, code="ragflow_kb_error", details=details)

class UploadError(RagFlowAPIException):
    """Indicates an error during file upload to RagFlow API."""
    def __init__(self, message: str = "File upload to RagFlow API failed", details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, status_code=500, code="ragflow_upload_error", details=details)

class WebSocketError(RagFlowAPIException):
    """Indicates an error related to WebSocket communication with RagFlow API."""
    def __init__(self, message: str = "WebSocket communication error with RagFlow API", details: Optional[Dict[str, Any]] = None):
        super().__init__(message=message, status_code=500, code="ragflow_websocket_error", details=details) 