"""
应用配置接口模块

提供前端应用配置信息，包括API设置等
"""

from config import settings
from utils.logger import logger
from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter()

class ApiConfigResponse(BaseModel):
    """API配置响应模型"""
    apiKey: str
    apiBaseUrl: str
    model: str

@router.get("/config", response_model=ApiConfigResponse)
async def get_api_config(request: Request) -> ApiConfigResponse:
    """
    获取前端API配置
    
    返回前端所需的API配置信息，包括基础URL、默认模型等
    前端使用相对路径调用此接口，无论在开发还是生产环境都能正确获取配置
    
    Returns:
        ApiConfigResponse: API配置信息
    """
    logger.info(f"API config requested from {request.client.host if request.client else 'unknown'}")
    
    # 构建API基础URL
    # 使用请求的host信息动态构建，确保与当前访问地址一致
    host = request.headers.get('host', f"localhost:{settings.app_port}")
    scheme = 'https' if request.headers.get('x-forwarded-proto') == 'https' else 'http'
    api_base_url = f"{scheme}://{host}{settings.api_prefix}"
    
    # 生成前端专用的API Key（可以是固定值或从配置读取）
    frontend_api_key = "sk-A6Bt70N70zl6ifqhmwvxJL1UDTB1doXW5wCyhWltYovJkKlF"
    
    config = ApiConfigResponse(
        apiKey=frontend_api_key,
        apiBaseUrl=api_base_url,
        model=settings.default_model
    )
    
    logger.info(f"API config returned: {api_base_url}, model: {settings.default_model}")
    
    return config 