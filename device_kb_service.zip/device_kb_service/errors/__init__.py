"""
错误和异常类模块
"""

from .exceptions import (
    RagFlowAPIException,
    RagFlowRequestError,
    RagFlowHTTPError,
    RagFlowUnexpectedError,
    RagFlowConcurrentLimitError,
    AuthenticationError,
    SessionError,
    KnowledgeBaseError,
    UploadError,
    WebSocketError
)


# 基础服务异常类
class ServiceError(Exception):
    """基础服务异常类"""
    def __init__(self, message: str, code: str = None, details: dict = None):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)

    def __str__(self) -> str:
        return f"ServiceError: {self.message} (Code: {self.code})"


class ServiceConnectionError(ServiceError):
    """服务连接异常"""
    def __init__(self, message: str = "Service connection failed", details: dict = None):
        super().__init__(message=message, code="connection_error", details=details)


class ServiceTimeoutError(ServiceError):
    """服务超时异常"""
    def __init__(self, message: str = "Service request timeout", details: dict = None):
        super().__init__(message=message, code="timeout_error", details=details)


# 导出所有异常类
__all__ = [
    # RagFlow 相关异常
    'RagFlowAPIException',
    'RagFlowRequestError',
    'RagFlowHTTPError',
    'RagFlowUnexpectedError',
    'RagFlowConcurrentLimitError',
    'AuthenticationError',
    'SessionError',
    'KnowledgeBaseError',
    'UploadError',
    'WebSocketError',
    
    # 基础服务异常
    'ServiceError',
    'ServiceConnectionError',
    'ServiceTimeoutError',
] 