from typing import List, Optional, Union, Dict, Any, ClassVar
from pydantic import BaseModel, Field, TypeAdapter

# --- OpenAI Compatible Request Models ---
class ChatMessage(BaseModel):
    role: str
    # OpenAI 最新规范中，content 既可以是字符串，也可以是形如 [{"type": "text", "text": "hi"}] 的列表
    content: Optional[Union[str, List[Dict[str, Any]]]] = None
    name: Optional[str] = None
    # tool_calls: Optional[List[Dict[str, Any]]] = None # For future tool use support
    # tool_call_id: Optional[str] = None # For future tool use support

class ChatCompletionRequest(BaseModel):
    model: Optional[str] = None
    messages: List[ChatMessage]
    temperature: Optional[float] = Field(default=None, ge=0.0, le=2.0)
    top_p: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    n: Optional[int] = Field(default=1, ge=1) # OpenAI default is 1
    stream: Optional[bool] = False
    stop: Optional[Union[List[str], str]] = None
    max_tokens: Optional[int] = Field(default=None, ge=1)
    presence_penalty: Optional[float] = Field(default=None, ge=-2.0, le=2.0)
    frequency_penalty: Optional[float] = Field(default=None, ge=-2.0, le=2.0)
    logit_bias: Optional[Dict[str, float]] = None
    user: Optional[str] = None
    # logprobs: Optional[bool] = False # For log probabilities
    # top_logprobs: Optional[int] = Field(default=None, ge=0, le=20) # If logprobs is true
    # response_format: Optional[Dict[str, str]] = None # e.g. {"type": "json_object"}
    # seed: Optional[int] = None
    # tools: Optional[List[Dict[str, Any]]] = None
    # tool_choice: Optional[Union[str, Dict[str, Any]]] = None

# --- Ollama API Models ---
class OllamaGenerateRequest(BaseModel):
    """Ollama generate request model"""
    model: str
    prompt: str
    stream: bool = False
    options: Optional[Dict[str, Any]] = None
    
class OllamaGenerateResponse(BaseModel):
    """Ollama generate response model"""
    model: str
    created_at: str
    response: str
    done: bool
    total_duration: Optional[int] = None
    load_duration: Optional[int] = None
    prompt_eval_count: Optional[int] = None
    prompt_eval_duration: Optional[int] = None
    eval_count: Optional[int] = None
    eval_duration: Optional[int] = None

class TextSummaryRequest(BaseModel):
    """Text summary request model"""
    text: str = Field(..., description="Text to summarize", min_length=1)
    max_length: int = Field(default=20, description="Maximum length of summary in characters", ge=1, le=100)

class TextSummaryResponse(BaseModel):
    """Text summary response model"""
    summary: str = Field(..., description="Generated summary")
    original_text: str = Field(..., description="Original input text")
    model: str = Field(..., description="Model used for generation")
    duration: Optional[float] = Field(None, description="Generation duration in seconds")
