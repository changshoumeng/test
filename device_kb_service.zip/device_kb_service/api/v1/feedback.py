import json
import time
from typing import Optional

from utils.logger import logger
from fastapi import APIRouter, Request, HTTPException, status
from pydantic import BaseModel, Field


# --- Request/Response Models ---
class FeedbackRequest(BaseModel):
    """用户反馈请求"""
    messageId: str = Field(..., description="消息ID")
    feedback: Optional[str] = Field(None, description="反馈类型: 'liked', 'disliked', null")
    content: Optional[str] = Field(None, description="用户消息内容")
    response: Optional[str] = Field(None, description="AI回复内容")
    timestamp: Optional[int] = Field(None, description="时间戳")

class FeedbackResponse(BaseModel):
    """反馈响应"""
    success: bool
    message: str
    data: Optional[dict] = None

class RegenerateRequest(BaseModel):
    """重新生成请求"""
    messageId: str = Field(..., description="消息ID")
    content: str = Field(..., description="原始用户消息")
    context: Optional[str] = Field(None, description="对话上下文")

class RegenerateResponse(BaseModel):
    """重新生成响应"""
    content: str
    messageId: str
    timestamp: int

router = APIRouter()

# 简单的内存存储（实际项目中应使用数据库）
feedback_storage = {}

@router.post("/feedback",
            response_model=FeedbackResponse,
            summary="Submit user feedback for a message",
            tags=["Feedback"])
async def submit_feedback(feedback_req: FeedbackRequest, request: Request) -> FeedbackResponse:
    """
    提交用户对AI回复的反馈（点赞/踩）
    """
    try:
        logger.info(f"Feedback submission: messageId={feedback_req.messageId}, feedback={feedback_req.feedback}")
        
        # 存储反馈数据
        feedback_data = {
            "messageId": feedback_req.messageId,
            "feedback": feedback_req.feedback,
            "content": feedback_req.content,
            "response": feedback_req.response,
            "timestamp": feedback_req.timestamp or int(time.time()),
            "recordedAt": int(time.time()),
            "clientIp": request.client.host if request.client else "unknown"
        }
        
        feedback_storage[feedback_req.messageId] = feedback_data
        
        # 记录到日志（用于分析）
        logger.info(f"Feedback recorded: {json.dumps(feedback_data, ensure_ascii=False)}")
        
        return FeedbackResponse(
            success=True,
            message="反馈已成功记录",
            data={
                "messageId": feedback_req.messageId,
                "feedback": feedback_req.feedback,
                "recordedAt": feedback_data["recordedAt"]
            }
        )
        
    except Exception as e:
        logger.error(f"Error submitting feedback: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": {"message": "反馈提交失败", "type": "internal_error"}}
        )

@router.get("/feedback/{message_id}",
           summary="Get feedback status for a message",
           tags=["Feedback"])
async def get_feedback(message_id: str, request: Request):
    """
    获取指定消息的反馈状态
    """
    try:
        logger.debug(f"Getting feedback for message: {message_id}")
        
        feedback_data = feedback_storage.get(message_id)
        if feedback_data:
            return {
                "messageId": message_id,
                "feedback": feedback_data["feedback"],
                "timestamp": feedback_data["recordedAt"]
            }
        else:
            return {
                "messageId": message_id,
                "feedback": None,
                "timestamp": None
            }
            
    except Exception as e:
        logger.error(f"Error getting feedback: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": {"message": "获取反馈状态失败", "type": "internal_error"}}
        )

@router.post("/regenerate",
            response_model=RegenerateResponse,
            summary="Regenerate AI response for a message",
            tags=["Feedback"])
async def regenerate_message(regen_req: RegenerateRequest, request: Request) -> RegenerateResponse:
    """
    重新生成AI回复
    """
    try:
        logger.info(f"Regeneration requested: messageId={regen_req.messageId}")
        
        # 这里应该调用实际的AI服务重新生成内容
        # 为了演示，我们简单地在原内容基础上添加标记
        original_content = regen_req.content
        
        # 模拟重新生成的内容（实际项目中应调用真实的AI服务）
        regenerated_content = f"[重新生成] {original_content}"
        
        # 记录重新生成请求
        logger.info(f"Message regenerated: messageId={regen_req.messageId}, original_length={len(original_content)}")
        
        return RegenerateResponse(
            content=regenerated_content,
            messageId=regen_req.messageId,
            timestamp=int(time.time())
        )
        
    except Exception as e:
        logger.error(f"Error regenerating message: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": {"message": "消息重新生成失败", "type": "internal_error"}}
        )

@router.get("/feedback/stats",
           summary="Get feedback statistics",
           tags=["Feedback"])
async def get_feedback_stats(request: Request):
    """
    获取反馈统计信息（管理用途）
    """
    try:
        total_feedback = len(feedback_storage)
        liked_count = sum(1 for f in feedback_storage.values() if f.get("feedback") == "liked")
        disliked_count = sum(1 for f in feedback_storage.values() if f.get("feedback") == "disliked")
        
        return {
            "total_feedback": total_feedback,
            "liked_count": liked_count,
            "disliked_count": disliked_count,
            "like_rate": liked_count / total_feedback if total_feedback > 0 else 0,
            "timestamp": int(time.time())
        }
        
    except Exception as e:
        logger.error(f"Error getting feedback stats: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": {"message": "获取统计信息失败", "type": "internal_error"}}
        ) 