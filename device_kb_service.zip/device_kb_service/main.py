import os
import sys

# Add the project root directory to sys.path
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

import time
import uvicorn
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import  FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from ragflow_sdk import RAGFlow

from config import settings
from utils.logger import logger, setup_logging
from api.v1 import chat as chat_router_v1
from api.v1 import models as models_router_v1
from api.v1 import init as init_router_v1
from api.v1 import feedback as feedback_router_v1
from api.v1 import config as config_router_v1
from errors.handlers import register_exception_handlers

# Initialize logging
_ = setup_logging()

logger.info(f"*****初始化日志系统 - 当前日志级别: {settings.log_level} *****")

@asynccontextmanager
async def lifespan(app_instance: FastAPI):
    """Application lifespan manager."""
    logger.info("Application startup sequence initiated...")
    logger.info(f"  App Name: {settings.app_name}, Version: {settings.app_version}")
    logger.info(f"  API Prefix: {settings.api_prefix}")
    logger.info(f"  Default Model: {settings.default_model}")
    
    # Check RagFlow configuration
    ragflow_configured = all([
        settings.ragflow_api_key,
        settings.ragflow_base_url,
        settings.ragflow_assistant_name
    ])
    
    logger.info(f"  RagFlow API Key configured: {'Yes' if settings.ragflow_api_key else 'NO'}")
    logger.info(f"  RagFlow Base URL: {settings.ragflow_base_url}")
    logger.info(f"  RagFlow Assistant: {settings.ragflow_assistant_name}")
    
    # Check authentication configuration
    auth_status = "Disabled (REQUIRE_AUTH=False)"
    if settings.require_auth:
        if settings.service_openai_api_key:
            auth_status = "Enabled (REQUIRE_AUTH=True, Key Provided)"
        else:
            auth_status = "Misconfigured (REQUIRE_AUTH=True, but SERVICE_OPENAI_API_KEY is missing)"
            logger.warning("API Key Authentication is REQUIRED but SERVICE_OPENAI_API_KEY is not set!")
    logger.info(f"  API Key Authentication: {auth_status}")
    
    # Initialize RagFlow SDK
    logger.info("Attempting to initialize RAGFlow...")
    if ragflow_configured:
        try:
            ragflow = RAGFlow(api_key=settings.ragflow_api_key, base_url=settings.ragflow_base_url)
            app_instance.state.ragflow = ragflow
            logger.info(f"RAGFlow initialized successfully, connected to: {settings.ragflow_base_url}")
            
            # Test connection by getting assistants
            try:
                assistants = ragflow.list_chats(name=settings.ragflow_assistant_name)
                logger.info(f"Found {len(assistants) if assistants else 0} chat assistants matching '{settings.ragflow_assistant_name}'.")
                if assistants:
                    assistant_names = [getattr(a, 'name', 'Unknown') for a in assistants[:3]]
                    logger.info(f"Assistant names: {assistant_names}")
            except Exception as e:
                logger.warning(f"Could not list assistants (non-fatal): {e}")
                
        except Exception as e:
            logger.error(f"Error during RAGFlow initialization: {e}", exc_info=True)
            app_instance.state.ragflow = None
    else:
        logger.warning("RagFlow configuration incomplete. RAGFlow will NOT be initialized.")
        app_instance.state.ragflow = None
    
    logger.info("Application startup sequence complete.")
    
    yield  # Application runs here
    
    # Shutdown logic
    logger.info("Application shutdown sequence initiated...")
    if hasattr(app_instance.state, 'ragflow') and app_instance.state.ragflow:
        try:
            # RAGFlow SDK doesn't seem to require explicit closing
            logger.info("RAGFlow connection closed.")
        except Exception as e:
            logger.error(f"Error closing RAGFlow: {e}", exc_info=True)
    logger.info("Application shutdown complete.")

def create_application() -> FastAPI:
    """Creates and configures the FastAPI application instance."""
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description="An OpenAI-compatible API for RagFlow Knowledge Base service.",
        openapi_url=f"{settings.api_prefix}/openapi.json",
        docs_url=f"{settings.api_prefix}/docs",
        redoc_url=f"{settings.api_prefix}/redoc",
        lifespan=lifespan
    )
    
    # Add CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # In production, specify actual domains
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Register exception handlers
    register_exception_handlers(app)
    
    # Add request processing middleware
    @app.middleware("http")
    async def process_time_middleware(request: Request, call_next):
        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time
        response.headers["X-Process-Time"] = str(process_time)
        
        # Log request metrics
        if request.url.path not in ["/"]:
            logger.debug(f"Request: {request.method} {request.url.path} - {response.status_code} - {process_time:.3f}s")
        
        return response
    
    # Include API routers
    app.include_router(init_router_v1.router, prefix=settings.api_prefix, tags=["Init"])
    app.include_router(chat_router_v1.router, prefix=settings.api_prefix, tags=["Chat"])
    app.include_router(models_router_v1.router, prefix=settings.api_prefix, tags=["Models"])
    app.include_router(feedback_router_v1.router, prefix=settings.api_prefix, tags=["Feedback"])
    app.include_router(config_router_v1.router, prefix=settings.api_prefix, tags=["Config"])

    # 静态文件服务配置
    frontend_dist_path = os.path.join(os.path.dirname(__file__), "html", "dist")
    if os.path.exists(frontend_dist_path):
        logger.info(f"Mounting static files from: {frontend_dist_path}")
        
        # 挂载静态文件（assets、images等）到 /dkb 路径下
        app.mount("/dkb/assets", StaticFiles(directory=os.path.join(frontend_dist_path, "assets")), name="dkb_assets")
        logger.info("Static file mounts configured successfully for /dkb path")
    else:
        logger.warning(f"Frontend dist directory not found at: {frontend_dist_path}")

    @app.get("/", include_in_schema=False)
    async def read_root():
        """Root endpoint - provides service information and frontend access link"""
        return {
            "service": settings.app_name,
            "version": settings.app_version,
            "description": "An OpenAI-compatible API for RagFlow Knowledge Base service",
            "frontend_url": "/dkb",
            "api_docs": f"{settings.api_prefix}/docs",
            "health_check": "/healthz"
        }
    
    @app.get("/dkb", include_in_schema=False)
    async def serve_frontend():
        """Serve the frontend application"""
        frontend_index = os.path.join(os.path.dirname(__file__), "html", "dist", "index.html")
        if os.path.exists(frontend_index):
            logger.debug(f"Serving frontend index from: {frontend_index}")
            return FileResponse(frontend_index)
        else:
            logger.error(f"Frontend index.html not found at: {frontend_index}")
            raise HTTPException(status_code=404, detail="Frontend not found")
    
    @app.get("/healthz", tags=["Service Health"])
    async def health_check():
        """Health check endpoint"""
        return {
            "status": "healthy",
            "service": settings.app_name,
            "version": settings.app_version,
            "timestamp": datetime.utcnow().isoformat(),
            "uptime": time.time() - app.state.start_time
        }
    
    # 处理 /dkb 路径下的静态文件和前端路由
    @app.get("/dkb/{filename:path}", include_in_schema=False)
    async def serve_dkb_static_files(filename: str):
        """处理 /dkb 路径下的静态文件和前端路由"""
        # 检查是否是静态文件（通过文件扩展名判断）
        static_extensions = {'.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.css', '.js', '.woff', '.woff2', '.ttf', '.eot'}
        file_extension = os.path.splitext(filename)[1].lower()
        
        if file_extension in static_extensions:
            # 尝试从 dist 根目录提供静态文件
            static_file_path = os.path.join(os.path.dirname(__file__), "html", "dist", filename)
            if os.path.exists(static_file_path) and os.path.isfile(static_file_path):
                logger.debug(f"Serving static file: /dkb/{filename}")
                return FileResponse(static_file_path)
            else:
                logger.warning(f"Static file not found: /dkb/{filename}")
                raise HTTPException(status_code=404, detail=f"Static file not found: {filename}")
        
        # 对于非静态文件路径，返回 index.html（让前端路由处理）
        frontend_index = os.path.join(os.path.dirname(__file__), "html", "dist", "index.html")
        if os.path.exists(frontend_index):
            logger.debug(f"SPA fallback: serving index.html for path: /dkb/{filename}")
            return FileResponse(frontend_index)
        else:
            logger.error(f"Frontend index.html not found at: {frontend_index}")
            raise HTTPException(status_code=404, detail="Frontend not found")

    
    # Store start time
    app.state.start_time = time.time()
    
    logger.info("FastAPI application created and configured.")
    return app

# Create application instance
app = create_application()

if __name__ == "__main__":
    logger.info(f"Starting {settings.app_name} v{settings.app_version}...")
    logger.info(f"  Host: {settings.app_host}, Port: {settings.app_port}")
    logger.info(f"  Log Level: {settings.log_level}")
    logger.info(f"  Auto-Reload: {settings.app_reload}")
    
    if not all([settings.ragflow_api_key, settings.ragflow_base_url]):
        logger.critical(
            "CRITICAL: RagFlow API is not fully configured. "
            "Please set RAGFLOW_API_KEY and RAGFLOW_BASE_URL."
        )
    
    uvicorn.run(
        "main:app",
        host=settings.app_host,
        port=settings.app_port,
        log_level=settings.log_level.lower(),
        reload=settings.app_reload,
        workers=settings.app_workers if settings.app_workers and not settings.app_reload else None
    ) 