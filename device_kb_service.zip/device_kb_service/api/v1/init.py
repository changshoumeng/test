"""
应用初始化接口模块

提供前端应用启动时所需的全部配置数据，包括：
- 助手列表配置
- 引导提示配置  
- 设备分类和故障问题库
- 应用配置信息
"""

from datetime import datetime
from typing import Dict, List, Any, Optional
from fastapi import APIRouter, Request, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from device_kb_service.utils.logger import logger
from device_kb_service.utils.file_loader import load_init_data_from_file, validate_init_data_structure
from device_kb_service.config import settings

router = APIRouter()

# 数据模型定义
class Agent(BaseModel):
    """助手配置模型"""
    id: str
    label: str
    value: str
    active: bool
    icon: str
    description: str
    system_message: str

class IntroPrompt(BaseModel):
    """引导提示模型"""
    id: str
    label: str
    value: str
    category: str
    order: int

class Question(BaseModel):
    """故障问题模型"""
    id: str
    label: str
    value: str
    severity: str
    frequency: str
    keywords: List[str]

class DeviceCategory(BaseModel):
    """设备分类模型"""
    id: str
    label: str
    value: str
    icon: str
    description: str
    questions: List[Question]

class Avatar(BaseModel):
    """头像配置模型"""
    imgSrc: str
    width: int
    height: int

class UISettings(BaseModel):
    """UI设置模型"""
    theme: str
    categories_per_page: int
    questions_per_toolbar: int
    questions_per_guess: int

class APISettings(BaseModel):
    """API设置模型"""
    default_model: str
    temperature: float
    stream: bool

class CompanyInfo(BaseModel):
    """公司信息模型"""
    name: str
    product_name: str
    logo: str
    description: Optional[str] = Field(None, description="产品描述")

class Welcome(BaseModel):
    """欢迎页配置模型"""
    header_icon: str = Field(description="欢迎页图标")
    header_title: str = Field(description="欢迎页主标题，支持HTML")
    header_subtitle: str = Field(description="欢迎页副标题，支持HTML")
    categories_title: str = Field(description="设备分类标题")
    common_questions_title: str = Field(description="常见问题标题")
    refresh_button_text: str = Field(description="刷新按钮文本")

class AppConfig(BaseModel):
    """应用配置模型"""
    avatars: Dict[str, Avatar]
    ui_settings: UISettings
    api_settings: APISettings
    company_info: CompanyInfo
    welcome: Optional[Welcome] = Field(None, description="欢迎页配置")

class InitData(BaseModel):
    """初始化数据模型"""
    agents: List[Agent]
    intro_prompts: List[IntroPrompt]
    device_categories: List[DeviceCategory]
    app_config: AppConfig

class InitResponse(BaseModel):
    """初始化响应模型"""
    object: str = "init_data"
    version: str
    timestamp: int
    data: InitData

def load_init_data_from_json() -> InitData:
    """
    从JSON文件加载初始化数据并转换为Pydantic模型
    
    根据配置的assistant_name选择对应的数据文件：
    - bao-焊接工艺AI助手 -> data/baogang.json
    - zhzg-设备故障诊断专家 -> data/zhenghua.json
    
    Returns:
        InitData: 转换后的初始化数据模型
        
    Raises:
        Exception: 文件读取或数据转换失败
    """
    try:
        # 根据assistant name选择对应的数据文件
        assistant_name = settings.ragflow_assistant_name
        if "bao" in assistant_name.lower() or "焊接" in assistant_name:
            data_file = "data/baogang.json"
        elif "zhzg" in assistant_name.lower() or "设备故障" in assistant_name:
            data_file = "data/zhenghua.json"
        else:
            # 默认使用zhenghua.json
            data_file = "data/zhenghua.json"
            logger.warning(f"Unknown assistant name: {assistant_name}, using default data file: {data_file}")
        
        logger.info(f"Loading init data for assistant '{assistant_name}' from file: {data_file}")
        
        # 从JSON文件加载原始数据
        raw_data = load_init_data_from_file(data_file)
        
        if raw_data is None:
            raise ValueError("Failed to load data from JSON file")
        
        # 验证数据结构
        if not validate_init_data_structure(raw_data):
            raise ValueError("Invalid data structure in JSON file")
        
        # 转换为Pydantic模型
        agents = [Agent(**agent) for agent in raw_data.get('agents', [])]
        
        intro_prompts = [IntroPrompt(**prompt) for prompt in raw_data.get('intro_prompts', [])]
        
        # 转换设备分类，包括嵌套的问题列表
        device_categories = []
        for category_data in raw_data.get('device_categories', []):
            questions = [Question(**question) for question in category_data.get('questions', [])]
            category = DeviceCategory(
                id=category_data['id'],
                label=category_data['label'],
                value=category_data['value'],
                icon=category_data['icon'],
                description=category_data['description'],
                questions=questions
            )
            device_categories.append(category)
        
        # 转换应用配置
        app_config_data = raw_data.get('app_config', {})
        
        avatars = {}
        for key, avatar_data in app_config_data.get('avatars', {}).items():
            avatars[key] = Avatar(**avatar_data)
        
        ui_settings = UISettings(**app_config_data.get('ui_settings', {}))
        api_settings = APISettings(**app_config_data.get('api_settings', {}))
        company_info = CompanyInfo(**app_config_data.get('company_info', {}))
        
        welcome = Welcome(**app_config_data.get('welcome', {})) if app_config_data.get('welcome') else None
        
        app_config = AppConfig(
            avatars=avatars,
            ui_settings=ui_settings,
            api_settings=api_settings,
            company_info=company_info,
            welcome=welcome
        )
        
        # 构建最终的初始化数据
        init_data = InitData(
            agents=agents,
            intro_prompts=intro_prompts,
            device_categories=device_categories,
            app_config=app_config
        )
        
        logger.info(f"Successfully converted JSON data to Pydantic models")
        logger.debug(f"Converted data summary: {len(agents)} agents, "
                    f"{len(intro_prompts)} prompts, "
                    f"{len(device_categories)} categories")
        
        return init_data
        
    except Exception as e:
        logger.error(f"Error loading and converting init data from JSON: {e}", exc_info=True)
        raise

@router.get("/init", response_model=InitResponse)
async def get_init_data(
    request: Request,
    version: Optional[str] = Query(None, description="客户端缓存版本，用于缓存验证")
) -> JSONResponse:
    """
    获取应用初始化数据
    
    直接从JSON文件读取数据，失败时快速失败。
    返回前端应用启动所需的全部配置数据，包括助手列表、引导提示、
    设备分类、故障问题和应用配置。
    
    Args:
        version: 客户端缓存版本，如果版本匹配则可以使用缓存
        
    Returns:
        InitResponse: 包含所有初始化数据的响应
        
    Raises:
        500: JSON文件读取失败或数据格式错误
    """
    logger.info(f"Init data requested from {request.client.host}")
    
    # 当前数据版本 - 可以根据实际需要调整版本号
    current_version = "1.0.3"
    
    # 如果客户端提供了version参数且版本匹配，可以返回304 Not Modified
    # 这里简化处理，总是返回数据
    if version and version == current_version:
        logger.debug(f"Client version {version} matches current version, but returning data anyway")
    
    try:
        # 直接从JSON文件加载数据，失败时快速失败
        logger.info("Loading init data from JSON file")
        init_data = load_init_data_from_json()
        
        # 构建响应
        response_data = InitResponse(
            object="init_data",
            version=current_version,
            timestamp=int(datetime.now().timestamp()),
            data=init_data
        )
        
        logger.info(f"Init data returned successfully - version: {current_version}, source: json_file")
        logger.debug(f"Data summary: {len(init_data.agents)} agents, "
                    f"{len(init_data.intro_prompts)} prompts, "
                    f"{len(init_data.device_categories)} categories, "
                    f"{sum(len(cat.questions) for cat in init_data.device_categories)} total questions")
        
        return JSONResponse(
            content=response_data.model_dump(),
            status_code=200,
            headers={
                "Cache-Control": "public, max-age=300",  # 缓存5分钟
                "ETag": f'"{current_version}"',
                "X-Data-Source": "json_file"
            }
        )
        
    except Exception as e:
        logger.error(f"Failed to load init data from JSON file: {e}", exc_info=True)
        return JSONResponse(
            content={
                "error": {
                    "message": f"初始化数据加载失败: {str(e)}",
                    "type": "api_error",
                    "code": "init_data_load_error"
                }
            },
            status_code=500
        ) 