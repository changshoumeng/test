import time
from typing import Generator, Dict, Any

from config import settings
from errors.exceptions import SessionError
from utils.logger import logger
from ragflow_sdk import RAGFlow


class RagFlowService:
    """
    RagFlow业务服务类，封装所有与RagFlow交互的逻辑。
    
    职责：
    - 聊天会话创建和管理
    - 消息发送和响应处理
    - 业务级错误处理
    """
    
    def __init__(self, ragflow_client: RAGFlow):
        """
        初始化RagFlow服务。
        
        Args:
            ragflow_client: RAGFlow SDK客户端实例
        """
        self.ragflow = ragflow_client
        self._active_sessions: Dict[str, Any] = {}
    
    def create_chat_session(self, assistant_name: str = None):
        """
        创建新的聊天会话。
        
        Args:
            assistant_name: 助手名称，默认使用配置中的名称
            
        Returns:
            创建的会话对象
            
        Raises:
            SessionError: 会话创建失败时抛出
        """
        try:
            # 使用提供的助手名称或默认配置
            assistant_name = assistant_name or settings.ragflow_assistant_name
            
            logger.info(f"查找聊天助手: {assistant_name}")
            logger.debug(f"调用 list_chats(name={assistant_name})")
            
            assistants = self.ragflow.list_chats(name=assistant_name)
            logger.info(f"list_chats 返回结果数量: {len(assistants) if assistants else 0}")
            
            if not assistants:
                error_msg = f"未找到名为 {assistant_name} 的聊天助手"
                logger.error(error_msg)
                # 尝试获取所有助手进行调试
                all_assistants = self.ragflow.list_chats()
                logger.info(f"当前可用的助手总数: {len(all_assistants) if all_assistants else 0}")
                if all_assistants:
                    assistant_names = [getattr(a, 'name', 'Unknown') for a in all_assistants[:5]]
                    logger.info(f"可用助手名称示例: {assistant_names}")
                raise SessionError(error_msg)
            
            assistant = assistants[0]
            logger.info(f"找到聊天助手: {assistant_name}, ID: {assistant.id}")
            
            # 创建会话
            logger.debug(f"调用 assistant.create_session() for assistant {assistant.id}")
            session = assistant.create_session()
            logger.info(f"创建会话成功，会话ID: {session.id}")
            
            # 添加短暂延迟以确保会话完全初始化
            time.sleep(0.5)
            logger.debug(f"会话初始化延迟完成")
            
            return session
            
        except Exception as e:
            if isinstance(e, SessionError):
                raise
            error_msg = f"创建聊天会话失败: {type(e).__name__}('{str(e)}')"
            logger.error(error_msg)
            logger.error(f"错误详情 - assistant_name: {assistant_name}")
            raise SessionError(error_msg)
    
    def send_message_stream(self, session, message: str) -> Generator[tuple[str, list], None, None]:
        """
        向会话发送消息并获取流式增量回复。
        
        专门用于流式响应，直接返回增量内容和引用信息，避免API层重复计算。
        
        Args:
            session: 会话对象
            message: 要发送的消息
            
        Yields:
            tuple[str, list]: (响应内容增量片段, 引用信息列表)
            
        Raises:
            Exception: 消息发送失败时抛出
        """
        try:
            logger.info(f"向会话 {session.id} 发送流式消息: {message[:100]}{'...' if len(message) > 100 else ''}")
            
            response_count = 0
            total_content_length = 0
            last_content = ""
            last_processed_content = ""  # 处理后的内容用于增量计算
            start_time = time.time()
            first_response_time = None
            final_references = []  # 存储最终的引用信息
            
            # Think模式状态跟踪
            in_think_mode = False
            think_ended = False
            
            # 引文缓冲机制
            citation_buffer = ""  # 缓冲不完整的引文
            last_output_length = 0  # 记录已输出内容的长度
            
            def convert_think_format(content: str, prev_processed: str) -> tuple[str, bool, bool]:
                """
                将ragflow的think格式转换为OpenAI风格
                
                Args:
                    content: 原始content
                    prev_processed: 之前已处理的内容
                    
                Returns:
                    tuple[转换后的内容, 是否在think模式, think是否已结束]
                """
                nonlocal in_think_mode, think_ended
                
                # 如果think已经结束，直接返回内容
                if think_ended:
                    return content, in_think_mode, think_ended
                
                # 检测think开始
                if '<think>' in content and not in_think_mode:
                    in_think_mode = True
                    logger.debug("检测到think模式开始")
                
                # 如果在think模式中
                if in_think_mode:
                    # 检测think结束标志
                    if '</think>\n\n' in content:
                        think_ended = True
                        logger.debug("检测到think模式结束")
                        
                        # 找到think结束位置
                        think_end_pos = content.find('</think>\n\n')
                        think_content = content[content.find('<think>'):think_end_pos]
                        
                        # 移除think标签，只保留内容，并在最后添加结束标签
                        think_inner = think_content.replace('<think>', '').replace('</think>', '')
                        converted_think = f"<think>{think_inner}</think>"
                        
                        # 拼接think后的正常内容
                        after_think = content[think_end_pos + len('</think>\n\n'):]
                        converted_content = converted_think + '\n\n' + after_think
                        
                        in_think_mode = False  # think结束
                        return converted_content, in_think_mode, think_ended
                    else:
                        # think还在进行中，移除结束标签
                        if '</think>' in content:
                            # 移除临时的结束标签
                            converted_content = content.replace('</think>', '')
                        else:
                            converted_content = content
                        return converted_content, in_think_mode, think_ended
                
                # 不在think模式，直接返回
                return content, in_think_mode, think_ended
            
            try:
                for response in session.ask(message, stream=True):
                    response_count += 1
                    current_time = time.time()
                    
                    # 记录首次响应时间
                    if first_response_time is None:
                        first_response_time = current_time
                        logger.info(f"首次响应延迟: {(first_response_time - start_time):.2f}秒")
                    
                    # 获取当前累积内容
                    raw_content = response.content or ""
                    
                    # 转换think格式
                    processed_content, current_in_think, current_think_ended = convert_think_format(raw_content, last_processed_content)
                    
                    # 记录引用信息（如果有）
                    if hasattr(response, 'reference') and response.reference:
                        logger.debug(f"响应块#{response_count}包含{len(response.reference)}条引用")
                        # 更新最终引用信息（通常在最后一个响应块中包含完整引用）
                        final_references = response.reference
                    
                    # 计算并返回增量内容 - 带引文缓冲处理
                    processed_length = len(processed_content)
                    if processed_length > len(last_processed_content):
                        delta_content = processed_content[len(last_processed_content):]
                        delta_length = len(delta_content)
                        total_content_length += delta_length
                        
                        # 记录增量信息
                        if delta_length > 0:
                            delta_preview = delta_content[:50].replace('\n', '\\n')
                            if len(delta_content) > 50:
                                delta_preview += "..."
                            logger.debug(f"响应块#{response_count}: +{delta_length}字符 '{delta_preview}' (think模式:{current_in_think})")
                            
                            # 引文缓冲处理逻辑
                            buffered_content, output_content = self._handle_citation_buffering(
                                delta_content, citation_buffer, processed_content, last_output_length
                            )
                            citation_buffer = buffered_content
                            
                            # 只有当有可输出内容时才进行格式转换和输出
                            if output_content:
                                # 统一引文格式：将[ID:数字]转换为##ID:数字$$
                                normalized_output = self._normalize_citation_format(output_content)
                                
                                # 更新已输出内容长度
                                last_output_length += len(output_content)
                                
                                # 返回格式化后的增量内容和当前的引用信息
                                yield (normalized_output, [])  # 流式过程中暂不返回引用
                            else:
                                logger.debug(f"响应块#{response_count}: 内容被缓冲，等待引文完整")
                        else:
                            logger.debug(f"响应块#{response_count}: 无新内容 (think模式:{current_in_think})")
                        
                        last_processed_content = processed_content
                    else:
                        logger.warning(f"响应块#{response_count}: 处理后内容长度未增加 (当前:{processed_length}, 之前:{len(last_processed_content)})")
                    
                    # 更新原始内容记录
                    last_content = raw_content
                
                # 在流结束时，处理剩余的缓冲内容
                if citation_buffer:
                    logger.debug(f"流结束时处理剩余缓冲内容: '{citation_buffer[:50]}{'...' if len(citation_buffer) > 50 else ''}'")
                    # 对剩余缓冲内容进行格式转换
                    normalized_buffer = self._normalize_citation_format(citation_buffer)
                    yield (normalized_buffer, [])
                
                # 在流结束时，如果有引用信息，发送一个特殊的标记
                if final_references:
                    logger.info(f"流式响应完成，包含{len(final_references)}条引用")
                    # 直接返回ragflow的原始引用数据，让前端处理格式适配
                    logger.debug(f"返回原始引用数据: {final_references[:1]}...")  # 只记录第一条作为示例
                    yield ("", final_references)  # 空内容，但包含原始引用信息
                
                # 统计信息
                total_time = time.time() - start_time
                avg_response_time = (total_time / response_count) if response_count > 0 else 0
                chars_per_second = (total_content_length / total_time) if total_time > 0 else 0
                
                logger.info(f"流式响应完成 - 响应块数:{response_count}, 总字符数:{total_content_length}, "
                          f"总耗时:{total_time:.2f}s, 平均响应间隔:{avg_response_time:.3f}s, "
                          f"生成速度:{chars_per_second:.1f}字符/秒, think处理:{'是' if think_ended else '否'}")
                
                # 警告：无响应情况
                if response_count == 0:
                    logger.warning("session.ask() 没有产生任何响应块")
                elif total_content_length == 0:
                    logger.warning("流式响应完成但未生成任何内容")
                    
            except Exception as ask_e:
                logger.error(f"session.ask() 调用失败: {type(ask_e).__name__}('{str(ask_e)}')")
                raise Exception(f"发送消息失败: {str(ask_e)}")
                
        except Exception as e:
            error_msg = f"发送流式消息失败: {type(e).__name__}('{str(e)}')"
            logger.error(error_msg)
            logger.error(f"错误详情 - session_id: {session.id}, message_length: {len(message)}")
            raise Exception(error_msg)
    
    def send_message(self, session, message: str) -> str:
        """
        向会话发送消息并获取完整回复。
        
        专门用于非流式响应，返回完整的响应内容。
        
        Args:
            session: 会话对象
            message: 要发送的消息
            
        Returns:
            str: 完整的响应内容
            
        Raises:
            Exception: 消息发送失败时抛出
        """
        try:
            logger.info(f"向会话 {session.id} 发送非流式消息: {message[:100]}{'...' if len(message) > 100 else ''}")
            
            start_time = time.time()
            response = session.ask(message, stream=False)
            response_time = time.time() - start_time
            
            raw_content = response.content or ""
            
            # 处理think格式转换（非流式版本）
            def convert_think_format_non_stream(content: str) -> str:
                """
                将ragflow的think格式转换为OpenAI风格（非流式版本）
                
                Args:
                    content: 原始content
                    
                Returns:
                    转换后的内容
                """
                # 如果包含完整的think标签，进行转换
                if '<think>' in content and '</think>\n\n' in content:
                    logger.debug("检测到完整think标签，进行格式转换")
                    
                    # 找到think结束位置
                    think_end_pos = content.find('</think>\n\n')
                    think_content = content[content.find('<think>'):think_end_pos]
                    
                    # 移除think标签，只保留内容，并在最后添加结束标签
                    think_inner = think_content.replace('<think>', '').replace('</think>', '')
                    converted_think = f"<think>{think_inner}</think>"
                    
                    # 拼接think后的正常内容
                    after_think = content[think_end_pos + len('</think>\n\n'):]
                    converted_content = converted_think + '\n\n' + after_think
                    
                    logger.debug(f"Think格式转换完成，原长度:{len(content)}, 转换后长度:{len(converted_content)}")
                    return converted_content
                elif '<think>' in content:
                    # 如果只有开始标签没有结束标签，移除未完成的think标签
                    logger.debug("检测到未完成的think标签，移除结束标签")
                    return content.replace('</think>', '')
                else:
                    # 没有think标签，直接返回
                    return content
            
            # 转换think格式
            processed_content = convert_think_format_non_stream(raw_content)
            
            # 统一引文格式：将[ID:数字]转换为##ID:数字$$
            normalized_content = self._normalize_citation_format(processed_content)
            
            logger.info(f"非流式响应完成 - 耗时:{response_time:.2f}s, 内容长度:{len(normalized_content)}字符")
            
            # 只在调试模式下显示内容预览
            if logger.level <= 10:  # DEBUG level
                content_preview = normalized_content[:200].replace('\n', '\\n')
                if len(normalized_content) > 200:
                    content_preview += "..."
                logger.debug(f"响应内容预览: '{content_preview}'")
            
            # 记录引用信息（如果有）
            if hasattr(response, 'reference') and response.reference:
                logger.info(f"响应包含{len(response.reference)}条引用")
            
            return normalized_content
            
        except Exception as e:
            error_msg = f"发送非流式消息失败: {type(e).__name__}('{str(e)}')"
            logger.error(error_msg)
            logger.error(f"错误详情 - session_id: {session.id}, message_length: {len(message)}")
            raise Exception(error_msg)
    
    def _handle_citation_buffering(self, delta_content: str, current_buffer: str, 
                                 full_content: str, last_output_length: int) -> tuple[str, str]:
        """
        处理引文缓冲逻辑，确保引文不被拆分
        
        Args:
            delta_content: 当前增量内容
            current_buffer: 当前缓冲内容
            full_content: 完整累积内容
            last_output_length: 已输出内容的长度
            
        Returns:
            tuple[str, str]: (新的缓冲内容, 可输出的内容)
        """
        import re
        
        # 合并缓冲内容和新增量
        combined_content = current_buffer + delta_content
        
        # 检查是否包含不完整的引文标记
        # 不完整的引文模式：以 [ID: 开头但没有匹配的 ]
        incomplete_citation_pattern = r'\[ID:[^\]]*$'
        
        # 检查末尾是否有不完整的引文
        incomplete_match = re.search(incomplete_citation_pattern, combined_content)
        
        if incomplete_match:
            # 发现不完整的引文，需要缓冲
            incomplete_start = incomplete_match.start()
            
            # 将不完整引文之前的内容作为可输出内容
            output_content = combined_content[:incomplete_start]
            
            # 将不完整引文作为新的缓冲内容
            new_buffer = combined_content[incomplete_start:]
            
            logger.debug(f"检测到不完整引文，缓冲: '{new_buffer}', 输出: '{output_content[:30]}{'...' if len(output_content) > 30 else ''}'")
            
            return new_buffer, output_content
        else:
            # 没有不完整的引文，检查是否有完整的引文需要处理
            # 检查缓冲内容中是否包含完整的引文
            complete_citation_pattern = r'\[ID:\d+\]'
            
            if current_buffer and re.search(complete_citation_pattern, combined_content):
                logger.debug(f"检测到完整引文，输出缓冲内容: '{combined_content[:50]}{'...' if len(combined_content) > 50 else ''}'")
                # 有完整引文，输出所有内容，清空缓冲
                return "", combined_content
            else:
                # 没有引文相关内容，直接输出
                return "", combined_content
    
    def get_or_create_session(self, session_key: str):
        """
        获取现有会话或创建新会话。
        
        Args:
            session_key: 会话唯一标识
            
        Returns:
            会话对象
            
        Raises:
            SessionError: 会话创建失败时抛出
        """
        logger.debug(f"检查会话缓存，session_key: {session_key}")
        
        if session_key in self._active_sessions:
            session = self._active_sessions[session_key]
            logger.info(f"使用缓存会话: session_id={session.id}")
            return session
        
        try:
            logger.info(f"创建新会话，session_key: {session_key}")
            session = self.create_chat_session()
            self._active_sessions[session_key] = session
            logger.info(f"新会话创建成功: session_id={session.id}")
            return session
        except Exception as e:
            error_msg = f"Failed to create session: {type(e).__name__}('{str(e)}')"
            logger.error(error_msg)
            logger.error(f"会话创建失败详情 - session_key: {session_key}")
            raise SessionError(f"Failed to create chat session: {str(e)}")
    
    def invalidate_session(self, session_key: str) -> None:
        """
        使会话缓存失效。
        
        Args:
            session_key: 要失效的会话标识
        """
        if session_key in self._active_sessions:
            del self._active_sessions[session_key]
            logger.info(f"会话已从缓存中移除: {session_key}")
    
    def get_session_count(self) -> int:
        """获取当前活跃会话数量。"""
        return len(self._active_sessions)
    
    def _normalize_citation_format(self, content: str) -> str:
        """
        统一引文格式：将[ID:数字]转换为##ID:数字$$
        
        这个方法确保所有引文都使用统一的格式，降低前端处理复杂性。
        
        Args:
            content: 原始内容
            
        Returns:
            str: 格式化后的内容
        """
        import re
        
        # 将[ID:数字]格式转换为##ID:数字$$格式
        normalized = re.sub(r'\[ID:(\d+)\]', r'##ID:\1$$', content)
        
        # 记录转换情况（仅在DEBUG级别）
        if '[ID:' in content:
            original_count = len(re.findall(r'\[ID:(\d+)\]', content))
            if original_count > 0:
                logger.debug(f"引文格式转换: {original_count}个[ID:数字]转换为##ID:数字$$格式")
        
        return normalized 
    