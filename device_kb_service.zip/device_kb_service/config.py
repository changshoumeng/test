import os
from typing import Optional, Literal, get_args
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, validator, SecretStr

# Determine the path to the .env file.
ENV_FILE_PATH = os.getenv("ENV_FILE", ".env")

class Settings(BaseSettings):
    # RagFlow API Settings
    ragflow_api_key: str = Field(
        # "ragflow-U3Y2MwZjU2MDk1ODExZjA5MTk1MDI0Mm"
        default="ragflow-FkOTIwNjE4MmVmZTExZjBhNjUzMDI0Mm",
        validation_alias="RAGFLOW_API_KEY"
    )
    ragflow_base_url: str = Field(
        # "http://192.168.18.185:50080"
        default="http://10.28.132.113",
        validation_alias="RAGFLOW_BASE_URL"
    )

    # RagFlow Assistant Name   bao-焊接工艺AI助手 zhzg-设备故障诊断专家
    ragflow_assistant_name: str = Field(
        default="zhzg-设备故障诊断专家",
        validation_alias="RAGFLOW_ASSISTANT_NAME"
    )
    
    # Ollama API Settings
    ollama_base_url: str = Field(
        default="http://10.28.132.113:11434",
        validation_alias="OLLAMA_BASE_URL"
    )
    ollama_model: str = Field(
        # "qwen3:4b"
        default="qwq-32b-fp16_32768:latest",
        validation_alias="OLLAMA_MODEL"
    )
    ollama_timeout: int = Field(
        default=30,
        ge=1,
        description="Timeout in seconds for Ollama requests"
    )
    ollama_max_retries: int = Field(
        default=3,
        ge=0,
        description="Maximum number of retries for Ollama operations"
    )
    ollama_retry_delay: float = Field(
        default=1.0,
        ge=0,
        description="Base delay in seconds between retries"
    )
    
    # OpenAI API Compatibility Settings
    default_model: str = Field(default="device_fault_master", validation_alias="DEFAULT_MODEL")
    api_prefix: str = Field(default="/device_kb/v1", validation_alias="API_PREFIX")
    service_openai_api_key: Optional[SecretStr] = Field(default=None, validation_alias="SERVICE_OPENAI_API_KEY")
    require_auth: bool = Field(default=False, validation_alias="REQUIRE_AUTH")
    
    # Service Configuration
    ragflow_max_retries: int = Field(default=3, ge=0, description="Maximum number of retries for RagFlow operations")
    ragflow_retry_delay: float = Field(default=0.5, ge=0, description="Base delay in seconds between retries")
    
    # Application Settings
    app_name: str = Field(default="DeviceKBService", description="Application name")
    app_version: str = Field(default="0.1.0", description="Application version")
    app_host: str = Field(default="0.0.0.0", description="Host to bind the server")
    app_port: int = Field(default=8089, description="Port to bind the server")
    app_timeout: int = Field(default=120, description="Timeout in seconds for RagFlow requests")
    app_reload: bool = Field(default=False, description="Enable auto-reload (development)")
    app_workers: Optional[int] = Field(default=None, description="Number of workers")
    
    # Logging Settings
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = Field(default="DEBUG")
    log_dir: str = Field(default="logs", description="Directory to store log files")
    
    model_config = SettingsConfigDict(
        env_file=ENV_FILE_PATH,
        env_file_encoding='utf-8',
        extra='ignore',
    )
    
    @validator("ragflow_base_url", pre=True, always=True)
    def _validate_ragflow_base_url(cls, v):
        if v and isinstance(v, str):
            return v.rstrip('/')
        return v
    
    @validator("log_level", pre=True, always=True)
    def _validate_log_level(cls, v):
        if isinstance(v, str):
            v_upper = v.upper()
            if v_upper in get_args(cls.__annotations__['log_level']):
                return v_upper
        return "INFO"
    
    @validator("api_prefix", pre=True, always=True)
    def _validate_api_prefix(cls, v):
        if v and isinstance(v, str):
            prefix = v.strip()
            if not prefix.startswith("/"):
                prefix = "/" + prefix
            if len(prefix) > 1 and prefix.endswith("/"):
                prefix = prefix.rstrip("/")
            return prefix
        return "/device_kb/v1"

# Instantiate settings
settings = Settings()
