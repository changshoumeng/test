"""
core module
核心服务模块
""" 