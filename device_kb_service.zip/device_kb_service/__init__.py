"""
device_kb_service package
设备知识库服务包
"""

__version__ = "1.0.0" 