# Device Knowledge Base Service

## 概述

Device KB Service 是一个提供 OpenAI 兼容 API 接口的知识库服务，基于 RagFlow 构建。该服务将 RagFlow 的知识库检索和对话能力封装为标准的 OpenAI API 格式，使其可以与各种支持 OpenAI API 的客户端兼容。

## 主要特性

- **OpenAI API 兼容**: 完全兼容 OpenAI Chat Completions API
- **知识库集成**: 基于 RagFlow 的强大知识库检索能力
- **流式响应支持**: 支持实时流式输出
- **会话管理**: 自动管理用户会话，保持对话上下文
- **灵活配置**: 通过环境变量轻松配置服务参数
- **可选认证**: 支持 API Key 认证机制

## 技术栈

- **框架**: FastAPI + Uvicorn
- **语言**: Python 3.11+
- **知识库**: RagFlow SDK
- **日志**: Loguru
- **配置**: Pydantic Settings

## 快速开始

### 1. 安装依赖

```bash
cd device_kb_service
pip install -r requirements.txt
```

### 2. 配置环境变量

创建 `.env` 文件（可选）:

```env
# RagFlow 配置
RAGFLOW_API_KEY=ragflow-U3Y2MwZjU2MDk1ODExZjA5MTk1MDI0Mm
RAGFLOW_BASE_URL=http://192.168.18.185:50080
RAGFLOW_ASSISTANT_NAME=老师傅AI助手

# 服务配置
APP_NAME=DeviceKBService
APP_VERSION=0.1.0
APP_HOST=0.0.0.0
APP_PORT=8089
LOG_LEVEL=INFO

# OpenAI API 兼容配置
DEFAULT_MODEL=ragflow-kb
API_PREFIX=/v1
REQUIRE_AUTH=false
# SERVICE_OPENAI_API_KEY=your-api-key-here
```

### 3. 启动服务

```bash
python main.py
```

服务将在 `http://localhost:8089` 启动。

## API 使用

### 使用 curl

```bash
# 发送聊天请求
curl -X POST http://localhost:8089/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "ragflow-kb",
    "messages": [
      {"role": "user", "content": "介绍一下设备维护流程"}
    ]
  }'
```

### 使用 OpenAI SDK

```python
from openai import OpenAI

# 配置客户端
client = OpenAI(
    api_key="dummy-key",  # 如果 REQUIRE_AUTH=false
    base_url="http://localhost:8089/v1"
)

# 发送请求
response = client.chat.completions.create(
    model="ragflow-kb",
    messages=[
        {"role": "user", "content": "介绍一下设备维护流程"}
    ]
)

print(response.choices[0].message.content)
```

### 流式响应

```python
# 流式响应
stream = client.chat.completions.create(
    model="ragflow-kb",
    messages=[
        {"role": "user", "content": "详细说明设备故障诊断步骤"}
    ],
    stream=True
)

for chunk in stream:
    if chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="")
```

## API 端点

- **聊天完成**: `POST /v1/chat/completions`
- **模型列表**: `GET /v1/models`
- **模型详情**: `GET /v1/models/{model_id}`
- **健康检查**: `GET /healthz`
- **服务指标**: `GET /metrics`
- **API 文档**: `GET /v1/docs`

详细的 API 文档请参考 [API.md](API.md)。

## 配置说明

### RagFlow 配置

- `RAGFLOW_API_KEY`: RagFlow API 密钥
- `RAGFLOW_BASE_URL`: RagFlow 服务地址
- `RAGFLOW_ASSISTANT_NAME`: 助手名称

### 服务配置

- `APP_HOST`: 服务监听地址（默认: 0.0.0.0）
- `APP_PORT`: 服务端口（默认: 8089）
- `LOG_LEVEL`: 日志级别（DEBUG/INFO/WARNING/ERROR）
- `API_PREFIX`: API 路径前缀（默认: /v1）

### 认证配置

- `REQUIRE_AUTH`: 是否启用认证（默认: false）
- `SERVICE_OPENAI_API_KEY`: API 密钥（启用认证时必需）

## 项目结构

```
device_kb_service/
├── api/                    # API 路由
│   ├── v1/                # V1 版本 API
│   │   ├── chat.py        # 聊天接口
│   │   └── models.py      # 模型接口
│   └── dependencies.py    # 依赖注入
├── core/                  # 核心功能
│   ├── ragflow_client.py  # RagFlow 客户端
│   └── models.py          # 数据模型
├── errors/                # 错误处理
│   ├── exceptions.py      # 异常定义
│   └── handlers.py        # 异常处理器
├── utils/                 # 工具模块
│   └── logger.py          # 日志配置
├── logs/                  # 日志文件
├── main.py               # 应用入口
├── config.py             # 配置管理
├── requirements.txt      # 依赖清单
├── API.md               # API 文档
└── readme.md            # 本文档
```

## 开发指南

### 添加新的模型

在 `api/v1/models.py` 的 `AVAILABLE_MODELS` 中添加：

```python
{
    "id": "your-model-id",
    "description": "Your model description",
    "owned_by": "ragflow"
}
```

### 自定义会话管理

当前使用内存存储会话，生产环境建议使用 Redis：

```python
# 在 api/v1/chat.py 中修改会话存储
import redis

redis_client = redis.Redis(host='localhost', port=6379, db=0)

def _get_or_create_session(client: RagFlowClient, session_key: str):
    # 实现 Redis 会话存储
    pass
```

### 日志配置

日志文件存储在 `logs/` 目录：
- `device_kb.log`: 所有日志
- `device_kb_error.log`: 错误日志

## 部署建议

### 使用 Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

CMD ["python", "main.py"]
```

### 使用 systemd

创建 `/etc/systemd/system/device-kb.service`:

```ini
[Unit]
Description=Device Knowledge Base Service
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/device_kb_service
ExecStart=/usr/bin/python3 main.py
Restart=always

[Install]
WantedBy=multi-user.target
```

### 使用 Nginx 反向代理

```nginx
server {
    listen 80;
    server_name kb-api.example.com;

    location / {
        proxy_pass http://localhost:8089;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_buffering off;  # 支持流式响应
    }
}
```

## 故障排查

### 常见问题

1. **RagFlow 连接失败**
   - 检查 `RAGFLOW_BASE_URL` 是否正确
   - 确认 RagFlow 服务是否运行
   - 验证 API Key 是否有效

2. **会话创建失败**
   - 检查助手名称是否正确
   - 确认 RagFlow 中存在对应的助手

3. **流式响应中断**
   - 检查网络连接稳定性
   - 增加超时时间配置

### 调试模式

设置 `LOG_LEVEL=DEBUG` 查看详细日志：

```bash
LOG_LEVEL=DEBUG python main.py
```

## 贡献指南

欢迎提交 Issue 和 Pull Request！

## 许可证

本项目基于 MIT 许可证开源。
